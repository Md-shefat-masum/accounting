<?php $__env->startSection('content'); ?>
    <transition name="fade" mode="out-in">
        <router-view></router-view>
    </transition>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\akunter.orika.com.bd\11-19-2020\blog\resources\views/backend/master/admin.blade.php ENDPATH**/ ?>