namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class <?php echo e($data['plural']); ?> extends Model
{

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var  array
     */
    protected $guarded = [
        'id'
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var  array
     */
    protected $casts = [
        ''
    ];
}
<?php /**PATH G:\akunter.orika.com.bd\11-19-2020\blog\resources\views/vendor/vueApi/model.blade.php ENDPATH**/ ?>