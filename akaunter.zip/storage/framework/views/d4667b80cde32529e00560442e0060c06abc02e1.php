<!doctype html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=Edge">
        <meta content="width=device-width, initial-scale=1" name="viewport">
        <title>Akaunter</title>

        <link rel="preconnect" href="https://fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;600;700;800&display=swap" rel="stylesheet">

        <!-- Favicon-->
        <link rel="icon" href="<?php echo e(asset('backend/assets/images/favicon.ico')); ?>" type="image/x-icon">
        <!-- Plugins Core Css -->
        <link href="<?php echo e(asset('backend/assets/css/app.min.css')); ?>" rel="stylesheet">
        <!-- Custom Css -->
        <link href="<?php echo e(asset('backend/assets/css/style.css')); ?>" rel="stylesheet" />
        <!-- Theme style. You can choose a theme from css/themes instead of get all themes -->
        <link href="<?php echo e(asset('backend/assets/css/styles/all-themes.css')); ?>" rel="stylesheet" />

        <!-- all css -->
        <link href="<?php echo e(asset('backend/assets/css/styles/all.css')); ?>" rel="stylesheet" />
    </head>

    <body class="light">
        <?php echo $__env->yieldContent('content'); ?>

        <!-- Plugins Js -->
        <script src="<?php echo e(asset('backend/assets/js/app.min.js')); ?>"></script>
        <script src="<?php echo e(asset('backend/assets/js/chart.min.js')); ?>"></script>
        <!-- Custom Js -->
        <script src="<?php echo e(asset('backend/assets/js/admin.js')); ?>"></script>
        <script src="<?php echo e(asset('backend/assets/js/pages/index.js')); ?>"></script>
        <script src="<?php echo e(asset('backend/assets/js/pages/charts/jquery-knob.js')); ?>"></script>
        <script src="<?php echo e(asset('backend/assets/js/pages/sparkline/sparkline-data.js')); ?>"></script>
        <script src="<?php echo e(asset('backend/assets/js/pages/medias/carousel.js')); ?>"></script>
        <script src="<?php echo e(asset('backend/assets/custom.js')); ?>"></script>
    </body>
</html>
<?php /**PATH G:\akunter.orika.com.bd\11-19-2020\blog\resources\views/backend/layouts/login_app.blade.php ENDPATH**/ ?>