<?php $__env->startSection('content'); ?>
    <transition name="fade" mode="out-in">
        <router-view></router-view>
    </transition>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/akaunter/public_html/resources/views/backend/master/admin.blade.php ENDPATH**/ ?>