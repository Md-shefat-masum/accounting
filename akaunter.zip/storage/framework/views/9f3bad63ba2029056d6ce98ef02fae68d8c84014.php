<?php $__env->startSection('content'); ?>
    <transition name="fade" mode="out-in">
        <router-view></router-view>
    </transition>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH J:\xampp\htdocs\Hsblco\akunter_2\resources\views/backend/master/admin.blade.php ENDPATH**/ ?>