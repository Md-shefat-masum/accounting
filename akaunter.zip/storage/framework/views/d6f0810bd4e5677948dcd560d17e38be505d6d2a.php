namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Model\<?php echo e($data['plural']); ?>;

class <?php echo e($data['plural']); ?>Controller extends Controller
{
    public function get(Request $request, $id){
      return <?php echo e($data['plural']); ?>::findOrFail($id);
    }

    public function list(Request $request){
      return <?php echo e($data['plural']); ?>::get();
    }

    public function create(Request $request){

      $validatedData = $request->validate([
<?php $__currentLoopData = $data['fields']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($field['required'] && $field['name'] !== 'id'): ?>
        '<?php echo e($field['name']); ?>' => 'required <?php if($field['max']): ?>|max:<?php echo e($field['max']); ?> <?php endif; ?>',
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      ],[
<?php $__currentLoopData = $data['fields']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($field['required'] && $field['name'] !== 'id'): ?>
        '<?php echo e($field['name']); ?>.required' => '<?php echo e($field['name']); ?> is a required field.',
<?php if($field['max']): ?>
        '<?php echo e($field['name']); ?>.max' => '<?php echo e($field['name']); ?> can only be <?php echo e($field['max']); ?> characters.',
<?php endif; ?>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      ]);

        $<?php echo e($data['plural_lower']); ?> = <?php echo e($data['plural']); ?>::create($request->all());
        return $<?php echo e($data['plural_lower']); ?>;
    }

    public function update(Request $request, $id){

      $validatedData = $request->validate([
<?php $__currentLoopData = $data['fields']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($field['required'] && $field['name'] !== 'id'): ?>
        '<?php echo e($field['name']); ?>' => 'required <?php if($field['max']): ?>|max:<?php echo e($field['max']); ?> <?php endif; ?>',
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      ],[
<?php $__currentLoopData = $data['fields']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($field['required'] && $field['name'] !== 'id'): ?>
        '<?php echo e($field['name']); ?>.required' => '<?php echo e($field['name']); ?> is a required field.',
<?php if($field['max']): ?>
        '<?php echo e($field['name']); ?>.max' => '<?php echo e($field['name']); ?> can only be <?php echo e($field['max']); ?> characters.',
<?php endif; ?>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      ]);

        $<?php echo e($data['plural_lower']); ?> = <?php echo e($data['plural']); ?>::findOrFail($id);
        $input = $request->all();
        $<?php echo e($data['plural_lower']); ?>->fill($input)->save();
        return $<?php echo e($data['plural_lower']); ?>;
    }

    public function delete(Request $request, $id){
        $<?php echo e($data['plural_lower']); ?> = <?php echo e($data['plural']); ?>::findOrFail($id);
        $<?php echo e($data['plural_lower']); ?>->delete();
    }
}
<?php /**PATH G:\akunter.orika.com.bd\11-19-2020\blog\resources\views/vendor/vueApi/controller.blade.php ENDPATH**/ ?>