<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quotation Email</title>
</head>
<body>
    
</body>
</html><?php /**PATH D:\xampp\htdocs\Hsblco\akunter_2\resources\views/emails/quotationEmail.blade.php ENDPATH**/ ?>