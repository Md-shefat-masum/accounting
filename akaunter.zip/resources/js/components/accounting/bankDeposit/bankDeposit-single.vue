<template>
    <!-- form section -->

    <form>
        <div class="right-content form1">
            <div id="contentRootPanel" class="fullpage">
                <div class="A54VNK-ce-a">
                    <div class="page-panel panel-default page-right-content">
                        <div>
                            <div class="panel-body page-panel-body">
                                <div data-id="v192168000209_1057048686843_2610">
                                    <div data-id="v192168001014_1433255688480_175">
                                        <div>
                                            <div class="row">
                                                <div class="col-sm-6">
                                                    <div data-id="v192168001014_1433255714875_176">
                                                        <div>
                                                            <div class="form-horizontal">
                                                                <div class="form-group row" data-id="v192168000005_1086017085640_4109">
                                                                    <div class="col-sm-4 col-xs-4 control-label"><label class="" for="gwt-uid-4054" style="font-weight: normal;">Date</label><span class="text-danger bold">*</span></div>
                                                                    <div class="col-sm-8 col-xs-8">
                                                                        <div class="input-group">
                                                                            <input type="text" class="form-control" id="gwt-uid-4054" />
                                                                            <div class="input-group-btn">
                                                                                <button type="button" class="btn btn-default" tabindex="-1"><span class="picto-font">\</span></button>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group row" data-id="v192168000005_1086017096796_4110">
                                                                    <div class="col-sm-4 col-xs-4 control-label">
                                                                        <label class="" for="gwt-uid-4057" style="font-weight: normal;">Bank Account</label>
                                                                        <span class="text-danger bold">*</span>
                                                                    </div>
                                                                    <div class="col-sm-8 col-xs-8">
                                                                        <div class="A54VNK-Ji-a">
                                                                            <div class="select-panel A54VNK-Ji-c">
                                                                                <select class="form-control" size="1" id="gwt-uid-4057">
                                                                                    <option value="37788">asia bank</option>
                                                                                    <option value="37757">city bank</option>
                                                                                </select>
                                                                            </div>
                                                                            <!-- <button type="button" class="btn btn-link A54VNK-Ji-b" style=""><span class="picto-font"></span></button> -->
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="btn-toolbar A54VNK-fj-a" aria-hidden="true" style="display: none;"></div>
                                                        <!-- <hr /> -->
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div data-id="v192168000005_1086017032750_4106" style="">
                                                        <div>
                                                            <div class="form-horizontal">
                                                                <div class="form-group row SimpleTextQuestion" data-id="v192168000005_1086017069531_4107">
                                                                    <div class="col-sm-4 col-xs-4 control-label">
                                                                        <label class="" for="gwt-uid-4061" style="font-weight: normal;">Description</label>
                                                                        <span class="text-danger bold" aria-hidden="true" style="display: none;">*</span>
                                                                    </div>
                                                                    <div class="col-sm-8 col-xs-8"><input type="text" class="form-control" id="gwt-uid-4061" /></div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="btn-toolbar A54VNK-fj-a" aria-hidden="true" style="display: none;"></div>
                                                        <!-- <hr /> -->
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="btn-toolbar A54VNK-fj-a" aria-hidden="true" style="display: none;"></div>
                                    </div>
                                    <div data-id="v192168000217_1068221452953_3148">
                                        <div>
                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <div data-id="v192168000021_1089019622546_4297">
                                                        <div>
                                                            <div>
                                                                <table
                                                                    __gwtcellbasedwidgetimpldispatchingfocus="true"
                                                                    __gwtcellbasedwidgetimpldispatchingblur="true"
                                                                    class="A54VNK-Xf-y table table-hover table-link empty"
                                                                    cellspacing="0"
                                                                    id="gwt-uid-4066"
                                                                    style="table-layout: fixed;"
                                                                >
                                                                    <colgroup>
                                                                        <col style="width: 30%;" />
                                                                        <col style="width: 30%;" />
                                                                        <col style="width: 30%;" />
                                                                        <col style="width: 30%;" />
                                                                        <col style="width: 10%;" />
                                                                    </colgroup>
                                                                    <thead>
                                                                        <tr __gwt_header_row="0">
                                                                            <th colspan="1" class="A54VNK-Xf-h A54VNK-Xf-f" __gwt_column="column-gwt-uid-4100" __gwt_header="header-gwt-uid-4101">
                                                                                <div><span class="ellipsis ellipsis-block header-small" data-title="Payment" data-toggle="tooltip">Payment</span> </div>
                                                                            </th>
                                                                            <th colspan="1" class="A54VNK-Xf-h" __gwt_column="column-gwt-uid-4102" __gwt_header="header-gwt-uid-4103">
                                                                                <div><span class="ellipsis ellipsis-block header-small" data-title="Customer" data-toggle="tooltip">Customer</span></div>
                                                                            </th>
                                                                            <th colspan="1" class="A54VNK-Xf-h" __gwt_column="column-gwt-uid-4104" __gwt_header="header-gwt-uid-4105">
                                                                                <div><span class="ellipsis ellipsis-block header-small" data-title="Description" data-toggle="tooltip">Description</span> </div>
                                                                            </th>
                                                                            <th colspan="1" class="A54VNK-Xf-h" __gwt_column="column-gwt-uid-4106" __gwt_header="header-gwt-uid-4107">
                                                                                <div><span class="ellipsis ellipsis-block header-small" data-title="Reference" data-toggle="tooltip">Reference</span></div>
                                                                            </th>
                                                                            <th colspan="1" class="A54VNK-Xf-h A54VNK-Xf-p" __gwt_column="column-gwt-uid-4108" __gwt_header="header-gwt-uid-4109">
                                                                                <div><span class="ellipsis ellipsis-block header-small" data-title="Amount" data-toggle="tooltip">Amount</span></div>
                                                                            </th>
                                                                        </tr>
                                                                    </thead>
                                                                    <tbody style="display: none;"></tbody>
                                                                    <tbody>
                                                                        <tr>
                                                                            <td align="center" colspan="5">
                                                                                <div>
                                                                                    <div style="width: 100%; height: 100%; padding: 0px; margin: 0px;">
                                                                                        <div style="width: 100%; height: 100%;"><div class="text-muted text-left">No items to show</div></div>
                                                                                    </div>
                                                                                    <div aria-hidden="true" style="width: 100%; height: 100%; padding: 0px; margin: 0px; display: none;">
                                                                                        <div aria-hidden="true" class="A54VNK-Xf-q" style="width: 100%; height: 100%; display: none;"><div class="text-muted text-left">Loading data...</div></div>
                                                                                    </div>
                                                                                </div>
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                    <tfoot aria-hidden="true" style="display: none;"></tfoot>
                                                                </table>
                                                            </div>
                                                        </div>
                                                        <div class="btn-toolbar A54VNK-fj-a" style="">
                                                            <button type="button" class="btn btn-default"><span class="picto-font">s</span> Add Payment</button><button type="button" class="btn btn-default"><span class="picto-font">s</span> Add Sales Receipt</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="btn-toolbar A54VNK-fj-a" aria-hidden="true" style="display: none;"></div>
                                    </div>
                                    <div data-id="v192168001014_1433255768588_177">
                                        <div>
                                            <div class="row">
                                                <div class="col-sm-6">
                                                    <div data-id="v192168001014_1433255790054_178" aria-hidden="true" style="display: none;">
                                                        <div><div class="form-horizontal"></div></div>
                                                        <div class="btn-toolbar A54VNK-fj-a" aria-hidden="true" style="display: none;"></div>
                                                        <hr />
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div data-id="v192168001014_1433255810136_179">
                                                        <div>
                                                            <div class="form-horizontal">
                                                                <div class="form-group row" data-id="v192168000022_1143218397515_498">
                                                                    <div class="col-sm-4 col-xs-4 control-label">
                                                                        <label class="" for="gwt-uid-4083" style="font-weight: normal;">Subtotal</label><span class="text-danger bold" aria-hidden="true" style="display: none;">*</span>
                                                                    </div>
                                                                    <div class="col-sm-8 col-xs-8"><input type="text" class="form-control" id="gwt-uid-4083" disabled="" style="text-align: right;" /></div>
                                                                </div>
                                                                <div class="form-group row" data-id="v192168001014_1433429306240_180">
                                                                    <div class="col-sm-4 col-xs-4 control-label">
                                                                        <label class="" for="gwt-uid-4084" style="font-weight: normal;">fees</label><span class="text-danger bold" aria-hidden="true" style="display: none;">*</span>
                                                                    </div>
                                                                    <div class="col-sm-8 col-xs-8"><input type="text" class="form-control" id="gwt-uid-4084" style="text-align: right;" /></div>
                                                                </div>
                                                                <div class="form-group row" data-id="v192168000022_1143210603937_279">
                                                                    <div class="col-sm-4 col-xs-4 control-label">
                                                                        <label class="" for="gwt-uid-4085" style="font-weight: normal;">Total</label><span class="text-danger bold" aria-hidden="true" style="display: none;">*</span>
                                                                    </div>
                                                                    <div class="col-sm-8 col-xs-8"><input type="text" class="form-control" id="gwt-uid-4085" disabled="" style="text-align: right;" /></div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="btn-toolbar A54VNK-fj-a" aria-hidden="true" style="display: none;"></div>
                                                        <hr />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="btn-toolbar A54VNK-fj-a" aria-hidden="true" style="display: none;"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <new-footer type="basic"/>
                </div>
            </div>
        </div>
    </form>

    <!-- form section -->
</template>

<script>
    import NewFooter from '../../../layouts/partials/new_footer'

    export default {
        components: {
            NewFooter,
        },
        name: 'Purchaseorder',
        data: function () {
            return {
                loaded: false,
                form: new Form({
                    "id": "",
                    "supplier": "",
                    "address": "",
                    "recipient": "",
                    "ref_number": "",
                    "date": "",
                    "payment_terms": "",
                    "currency": "",
                    "product": "",
                    "document_note": "",
                    "subtotal": "",
                    "discount_rate": "",
                    "discount_amount": "",
                    "vat": "",
                    "total": "",
                    "delivery_date": "",
                    "type": "",
                    "delivery_address": "",
                    "project": "",
                    "delivery_status": "",
                    "billing_status": "",
                    "assigned_to": "",
                    "private_note": "",
                    "attachments": "",
                    "created_at": "",
                    "updated_at": "",
                })
            }
        },
        created: function () {
            this.getPurchaseorder();
        },
        methods: {
            getPurchaseorder: function (Purchaseorder) {

                var that = this;
                this.form.get('/api/purchaseorders/' + this.$route.params.id).then(function (response) {
                    that.form.fill(response.data);
                    that.loaded = true;
                });

            },
            updatePurchaseorder: function () {

                var that = this;
                this.form.put('/api/purchaseorders/' + this.$route.params.id).then(function (response) {
                    that.form.fill(response.data);
                })

            },
            deletePurchaseorder: function () {

                var that = this;
                this.form.delete('/api/purchaseorders/' + this.$route.params.id).then(function (response) {
                    that.form.fill(response.data);
                    that.$router.push('/super-admin/purchaseorders');
                })

            }
        }
    }
</script>
