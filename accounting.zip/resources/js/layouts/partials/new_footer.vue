<template>
    <!-- footer part start -->
    <div class="navbar navbar-fixed-bottom navbar-custom A54VNK-be-c formfooter">
        <div class="A54VNK-Vf-d">
            <div class="A54VNK-Vf-e"></div>
            <div class="btn-toolbar A54VNK-Vf-c">
                <button type="button" class="btn btn-default cancel_btn">Cancel</button>
                <button type="submit" class="btn btn-primary done_btn">Done</button>
            </div>
        </div>
    </div>
    <!-- footer part end -->
</template>
