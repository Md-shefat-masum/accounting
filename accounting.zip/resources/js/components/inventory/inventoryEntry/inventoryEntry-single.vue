<template>
    <!-- form section -->

    <form>
        <div class="right-content form1">
            <div id="contentRootPanel" class="fullpage">
                <div class="A54VNK-ce-a">
                    <div class="page-panel panel-default page-right-content">
                        <div>
                            <div class="panel-body page-panel-body">
                                <div data-id="v192168000011_1106212999781_168">
                                    <div data-id="v192168000011_1106213227578_212" style="">
                                        <div>
                                            <div class="form-horizontal">
                                                <div class="form-group row" data-id="v192168000011_1106213391093_293">
                                                    <div class="col-sm-4 col-xs-4 control-label">
                                                        <label class="" for="gwt-uid-57792" style="font-weight: normal;">Date</label>
                                                        <span class="text-danger bold">*</span>
                                                    </div>
                                                    <div class="col-sm-8 col-xs-8">
                                                        <div class="input-group">
                                                            <input type="text" class="form-control" id="gwt-uid-57792" />
                                                            <div class="input-group-btn">
                                                                <button type="button" class="btn btn-default" tabindex="-1"><span class="picto-font">\</span></button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-group row" data-id="v192168000011_1106213402234_294">
                                                    <div class="col-sm-4 col-xs-4 control-label">
                                                        <label class="" for="gwt-uid-57798" style="font-weight: normal;">Storage location</label>
                                                        <span class="text-danger bold">*</span>
                                                    </div>
                                                    <div class="col-sm-8 col-xs-8">
                                                        <div class="dropdown">
                                                            <input type="text" class="form-control A54VNK-Ki-b" data-toggle="dropdown" autocomplete="off" role="button" placeholder="Search results" id="gwt-uid-57798" />
                                                            <ul class="dropdown-menu A54VNK-Ki-a">
                                                                <li class="active">
                                                                    <a class="ellipsis-block" role="button" title="MAIN LOCATION">
                                                                        <strong>MAIN</strong> <strong>LOCATION</strong>
                                                                    </a>
                                                                </li>
                                                                <li class="divider"></li>
                                                                <li class="">
                                                                    <a class="ellipsis-block" role="button">Start the search</a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-group SimpleTextQuestion row" data-id="v192168000011_1106213409375_295">
                                                    <div class="col-sm-4 col-xs-4 control-label">
                                                        <label class="" for="gwt-uid-57800" style="font-weight: normal;">Description</label>
                                                        <span class="text-danger bold" aria-hidden="true" style="display: none;">*</span>
                                                    </div>
                                                    <div class="col-sm-8 col-xs-8">
                                                        <input type="text" class="form-control" id="gwt-uid-57800" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="btn-toolbar A54VNK-fj-a" aria-hidden="true" style="display: none;"></div>
                                        <hr />
                                    </div>
                                    <div data-id="v192168000011_1106213234906_213">
                                        <div>
                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <div data-id="v192168000011_1106213244437_215">
                                                        <div>
                                                            <div>
                                                                <table
                                                                    __gwtcellbasedwidgetimpldispatchingfocus="true"
                                                                    __gwtcellbasedwidgetimpldispatchingblur="true"
                                                                    class="A54VNK-Xf-y table table-hover table-link A54VNK-Xf-z empty"
                                                                    cellspacing="0"
                                                                    id="gwt-uid-57806"
                                                                    style="table-layout: fixed;"
                                                                >
                                                                    <colgroup>
                                                                        <col style="width: 30%;" />
                                                                        <col style="width: 30%;" />
                                                                        <col style="width: 30%;" />
                                                                        <col style="width: 30%;" />
                                                                        <col style="width: 30%;" />
                                                                    </colgroup>
                                                                    <thead>
                                                                        <tr __gwt_header_row="0">
                                                                            <th colspan="1" class="A54VNK-Xf-h A54VNK-Xf-f" __gwt_column="column-gwt-uid-57831" __gwt_header="header-gwt-uid-57832">
                                                                                <div>
                                                                                    <span class="ellipsis ellipsis-block header-small" data-title="Code" data-toggle="tooltip">Code</span>
                                                                                    <!-- <span class="header-normal">Code</span> -->
                                                                                </div>
                                                                            </th>
                                                                            <th colspan="1" class="A54VNK-Xf-h" __gwt_column="column-gwt-uid-57833" __gwt_header="header-gwt-uid-57834">
                                                                                <div>
                                                                                    <span class="ellipsis ellipsis-block header-small" data-title="Product" data-toggle="tooltip">Product</span>
                                                                                    <!-- <span class="header-normal">Product</span> -->
                                                                                </div>
                                                                            </th>
                                                                            <th colspan="1" class="A54VNK-Xf-h" __gwt_column="column-gwt-uid-57835" __gwt_header="header-gwt-uid-57836">
                                                                                <div>
                                                                                    <span class="ellipsis ellipsis-block header-small" data-title="Quantity" data-toggle="tooltip">Quantity</span>
                                                                                    <!-- <span class="header-normal">Quantity</span> -->
                                                                                </div>
                                                                            </th>
                                                                            <th colspan="1" class="A54VNK-Xf-h" __gwt_column="column-gwt-uid-57837" __gwt_header="header-gwt-uid-57838">
                                                                                <div>
                                                                                    <span class="ellipsis ellipsis-block header-small" data-title="Unit Price" data-toggle="tooltip">Unit Price</span>
                                                                                    <!-- <span class="header-normal">Unit Price</span> -->
                                                                                </div>
                                                                            </th>
                                                                            <th colspan="1" class="A54VNK-Xf-h A54VNK-Xf-p" __gwt_column="column-gwt-uid-57839" __gwt_header="header-gwt-uid-57840">
                                                                                <div>
                                                                                    <span class="ellipsis ellipsis-block header-small" data-title="Total Amount" data-toggle="tooltip">Total Amount</span>
                                                                                    <!-- <span class="header-normal">Total Amount</span> -->
                                                                                </div>
                                                                            </th>
                                                                        </tr>
                                                                    </thead>
                                                                    <tbody style="display: none;"></tbody>
                                                                    <tbody>
                                                                        <tr>
                                                                            <td align="center" colspan="5">
                                                                                <div>
                                                                                    <div style="width: 100%; height: 100%; padding: 0px; margin: 0px;">
                                                                                        <div style="width: 100%; height: 100%;"><div class="text-muted text-left">No items to show</div></div>
                                                                                    </div>
                                                                                    <div aria-hidden="true" style="width: 100%; height: 100%; padding: 0px; margin: 0px; display: none;">
                                                                                        <div aria-hidden="true" class="A54VNK-Xf-q" style="width: 100%; height: 100%; display: none;"><div class="text-muted text-left">Loading data...</div></div>
                                                                                    </div>
                                                                                </div>
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                    <tfoot aria-hidden="true" style="display: none;"></tfoot>
                                                                </table>
                                                            </div>
                                                        </div>
                                                        <div class="btn-toolbar A54VNK-fj-a" style="">
                                                            <button type="button" class="btn btn-default"><span class="picto-font">+</span> Add a Product</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="btn-toolbar A54VNK-fj-a" aria-hidden="true" style="display: none;"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <new-footer type="basic"/>
                </div>
            </div>
        </div>
    </form>

    <!-- form section -->
</template>

<script>
    import NewFooter from '../../../layouts/partials/new_footer'

    export default {
        components: {
            NewFooter,
        },
        name: 'Purchaseorder',
        data: function () {
            return {
                loaded: false,
                form: new Form({
                    "id": "",
                    "supplier": "",
                    "address": "",
                    "recipient": "",
                    "ref_number": "",
                    "date": "",
                    "payment_terms": "",
                    "currency": "",
                    "product": "",
                    "document_note": "",
                    "subtotal": "",
                    "discount_rate": "",
                    "discount_amount": "",
                    "vat": "",
                    "total": "",
                    "delivery_date": "",
                    "type": "",
                    "delivery_address": "",
                    "project": "",
                    "delivery_status": "",
                    "billing_status": "",
                    "assigned_to": "",
                    "private_note": "",
                    "attachments": "",
                    "created_at": "",
                    "updated_at": "",
                })
            }
        },
        created: function () {
            this.getPurchaseorder();
        },
        methods: {
            getPurchaseorder: function (Purchaseorder) {

                var that = this;
                this.form.get('/api/purchaseorders/' + this.$route.params.id).then(function (response) {
                    that.form.fill(response.data);
                    that.loaded = true;
                });

            },
            updatePurchaseorder: function () {

                var that = this;
                this.form.put('/api/purchaseorders/' + this.$route.params.id).then(function (response) {
                    that.form.fill(response.data);
                })

            },
            deletePurchaseorder: function () {

                var that = this;
                this.form.delete('/api/purchaseorders/' + this.$route.params.id).then(function (response) {
                    that.form.fill(response.data);
                    that.$router.push('/super-admin/purchaseorders');
                })

            }
        }
    }
</script>
