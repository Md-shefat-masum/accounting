<template>
    <!-- form section -->

    <form action="">
        <div class="right-content form2">
            <div id="contentRootPanel" class="fullpage">
                <div class="page-panel page-right-content A54VNK-be-a">
                    <div class="panel-body page-panel-body">
                        <div class="container-fluid A54VNK-Ae-e">
                            <div class="row">
                                <div class="col-12 col-sm-4">
                                    <div class="form-group floating-label">
                                        <div class="dropdown form-component">
                                            <input type="text" class="form-control A54VNK-wg-l" id="gwt-uid-2077" data-toggle="dropdown" autocomplete="off">
                                            <label class="control-label form-question ellipsis" for="gwt-uid-2077">Paid to</label>
                                            <ul class="dropdown-menu A54VNK-ge-d">
                                                <li class="tab active">
                                                    <a class="ellipsis-block" href="#" role="button">
                                                        <span class="A54VNK-ih-a picto picto-font"></span>
                                                        <span>Recents</span>
                                                    </a>
                                                </li>
                                                <li class="tab"><a class="" href="#" role="button"><span>Supplier</span>
                                                </a></li>
                                                <li class="tab"><a class="" href="#" role="button"><span>Customer</span>
                                                </a></li>
                                                <li class="tab"><a class="" href="#" role="button"><span>Employee</span>
                                                </a></li>
                                                <li class="text-center disabled A54VNK-wg-i">
                                                    <a> Your recent payees will appear here. </a></li>
                                            </ul>

                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 offset-0 col-sm-3 offset-sm-5">
                                    <div class="form-group floating-label mandatory focused">
                                        <div class="form-component A54VNK-pd-c">
                                            <input type="text" class="form-control A54VNK-wg-l" id="gwt-uid-2092">
                                            <label class="control-label form-question ellipsis" style="transform: translateY(6px);" for="gwt-uid-2092">Billing date</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-12">
                                    <div class="row">
                                        <div class="col-12">
                                            <div class="A54VNK-If-b">
                                                <div class="text-muted text-left A54VNK-If-c" aria-hidden="true" style="display: none;">No items
                                                                                                                                        to show
                                                </div>
                                                <div>
                                                    <div>
                                                        <div class="row A54VNK-Mi-b">
                                                            <div class="col-12 col-sm-3 object-list-first-cell">
                                                                <div class="form-group floating-label focused mandatory">
                                                                    <div class="dropdown form-component">
                                                                        <input type="text" class="form-control A54VNK-ie-i" id="gwt-uid-2111" data-toggle="dropdown" autocomplete="off">
                                                                        <label class="control-label form-question ellipsis" style="transform: translateY(6px);" for="gwt-uid-2111">Category</label>
                                                                        <ul class="dropdown-menu A54VNK-ie-d" style="overflow-y: visible;">
                                                                            <li class="dropdown-header" style="margin-top: 8px;">EXPENSE</li>
                                                                            <li class="dropdown-submenu">
                                                                                <a class="ellipsis-block" role="button">
                                                                                    <div class="A54VNK-nh-c">
                                                                                        <div class="A54VNK-nh-e">
                                                                                            <div class="A54VNK-nh-d" style="background-color: rgb(156, 39, 176);">
                                                                                            </div>
                                                                                            <div>
                                                                                                <div>Bank Services</div>
                                                                                            </div>
                                                                                        </div>
                                                                                        <span class="picto-font A54VNK-nh-f"></span>
                                                                                    </div>
                                                                                </a>
                                                                                <ul class="dropdown-menu">
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Merchant Account Fees</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Other Bank Charges</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="divider"></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">Customise Categories</a>
                                                                                    </li>
                                                                                </ul>
                                                                            </li>
                                                                            <li class="dropdown-submenu">
                                                                                <a class="ellipsis-block" role="button">
                                                                                    <div class="A54VNK-nh-c">
                                                                                        <div class="A54VNK-nh-e">
                                                                                            <div class="A54VNK-nh-d" style="background-color: rgb(177, 53, 166);">
                                                                                            </div>
                                                                                            <div>
                                                                                                <div>Communication Expenses</div>
                                                                                            </div>
                                                                                        </div>
                                                                                        <span class="picto-font A54VNK-nh-f"></span>
                                                                                    </div>
                                                                                </a>
                                                                                <ul class="dropdown-menu">
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Advertising Materials</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Advertising Services</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Internet</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Licenses and Regulatory Fees</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Postage and Delivery</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Printing</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Subscriptions</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Telephone</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="divider"></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">Customise Categories</a>
                                                                                    </li>
                                                                                </ul>
                                                                            </li>
                                                                            <li class="dropdown-submenu">
                                                                                <a class="ellipsis-block" role="button">
                                                                                    <div class="A54VNK-nh-c">
                                                                                        <div class="A54VNK-nh-e">
                                                                                            <div class="A54VNK-nh-d" style="background-color: rgb(102, 109, 50);">
                                                                                            </div>
                                                                                            <div>
                                                                                                <div>Employee Salary or Wages</div>
                                                                                            </div>
                                                                                        </div>
                                                                                        <span class="picto-font A54VNK-nh-f"></span>
                                                                                    </div>
                                                                                </a>
                                                                                <ul class="dropdown-menu">
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Bonuses and Gratuities</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Disability Insurance</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Education and Training</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Education Tax</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Employee Salary or Wage</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Employee Savings Plan</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Health Insurance</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Labour Costs</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>National Insurance</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Other Employee Benefits</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Paid Vacation</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Payroll Fee</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Payroll Tax</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Retirement / Pension</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="divider"></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">Customise Categories</a>
                                                                                    </li>
                                                                                </ul>
                                                                            </li>
                                                                            <li class="dropdown-submenu">
                                                                                <a class="ellipsis-block" role="button">
                                                                                    <div class="A54VNK-nh-c">
                                                                                        <div class="A54VNK-nh-e">
                                                                                            <div class="A54VNK-nh-d" style="background-color: rgb(0, 101, 146);">
                                                                                            </div>
                                                                                            <div>
                                                                                                <div>General Business Expense</div>
                                                                                            </div>
                                                                                        </div>
                                                                                        <span class="picto-font A54VNK-nh-f"></span>
                                                                                    </div>
                                                                                </a>
                                                                                <ul class="dropdown-menu">
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Computer Rental</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Equipment Purchase</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Equipment Rental</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Furnishing Rental</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Office Expenses</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Other Business Expense</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Purchase of Company Vehicle</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Supplies and Materials</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Vehicle Rental</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="divider"></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">Customise Categories</a>
                                                                                    </li>
                                                                                </ul>
                                                                            </li>
                                                                            <li class="dropdown-submenu">
                                                                                <a class="ellipsis-block" role="button">
                                                                                    <div class="A54VNK-nh-c">
                                                                                        <div class="A54VNK-nh-e">
                                                                                            <div class="A54VNK-nh-d" style="background-color: rgb(113, 80, 0);"></div>
                                                                                            <div>
                                                                                                <div>Goods and Commodities</div>
                                                                                            </div>
                                                                                        </div>
                                                                                        <span class="picto-font A54VNK-nh-f"></span>
                                                                                    </div>
                                                                                </a>
                                                                                <ul class="dropdown-menu">
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Product Purchase for Resale</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Raw Materials</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="divider"></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">Customise Categories</a>
                                                                                    </li>
                                                                                </ul>
                                                                            </li>
                                                                            <li class="dropdown-submenu">
                                                                                <a class="ellipsis-block" role="button">
                                                                                    <div class="A54VNK-nh-c">
                                                                                        <div class="A54VNK-nh-e">
                                                                                            <div class="A54VNK-nh-d" style="background-color: rgb(124, 8, 47);"></div>
                                                                                            <div>
                                                                                                <div>Insurance</div>
                                                                                            </div>
                                                                                        </div>
                                                                                        <span class="picto-font A54VNK-nh-f"></span>
                                                                                    </div>
                                                                                </a>
                                                                                <ul class="dropdown-menu">
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Liability Insurance</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Other Insurance</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Vehicle Insurance</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="divider"></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">Customise Categories</a>
                                                                                    </li>
                                                                                </ul>
                                                                            </li>
                                                                            <li class="dropdown-submenu">
                                                                                <a class="ellipsis-block" role="button">
                                                                                    <div class="A54VNK-nh-c">
                                                                                        <div class="A54VNK-nh-e">
                                                                                            <div class="A54VNK-nh-d" style="background-color: rgb(21, 108, 165);">
                                                                                            </div>
                                                                                            <div>
                                                                                                <div>Loans</div>
                                                                                            </div>
                                                                                        </div>
                                                                                        <span class="picto-font A54VNK-nh-f"></span>
                                                                                    </div>
                                                                                </a>
                                                                                <ul class="dropdown-menu">
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Company Auto Loan Bank Fee</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Company Vehicle Lease Payment</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Equipment Loan Bank Fee</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Lease-to-own Company Vehicle Payment</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Loan Interest - Paid</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Loan Principale - Paid</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Mortgage Bank Fee</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Office Equipment Lease Payment</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Other Fundings</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Other Loan Fee</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Property Improvement Loan Bank Fee</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Real Estate Lease Bank Fee</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="divider"></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">Customise Categories</a>
                                                                                    </li>
                                                                                </ul>
                                                                            </li>
                                                                            <li class="dropdown-submenu">
                                                                                <a class="ellipsis-block" role="button">
                                                                                    <div class="A54VNK-nh-c">
                                                                                        <div class="A54VNK-nh-e">
                                                                                            <div class="A54VNK-nh-d" style="background-color: rgb(97, 97, 97);"></div>
                                                                                            <div>
                                                                                                <div>Owner Salary or Wages</div>
                                                                                            </div>
                                                                                        </div>
                                                                                        <span class="picto-font A54VNK-nh-f"></span>
                                                                                    </div>
                                                                                </a>
                                                                                <ul class="dropdown-menu">
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Owner Disability Insurance</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Owner Insurance - Social</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Owner National Insurance</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Owner Retirement / Pension</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Owner Salary or Wages (gross)</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Owner Salary or Wages (net)</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Sole Proprietor Social Insurance</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="divider"></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">Customise Categories</a>
                                                                                    </li>
                                                                                </ul>
                                                                            </li>
                                                                            <li class="dropdown-submenu">
                                                                                <a class="ellipsis-block" role="button">
                                                                                    <div class="A54VNK-nh-c">
                                                                                        <div class="A54VNK-nh-e">
                                                                                            <div class="A54VNK-nh-d" style="background-color: rgb(197, 31, 130);">
                                                                                            </div>
                                                                                            <div>
                                                                                                <div>Personal Expense</div>
                                                                                            </div>
                                                                                        </div>
                                                                                        <span class="picto-font A54VNK-nh-f"></span>
                                                                                    </div>
                                                                                </a>
                                                                                <ul class="dropdown-menu">
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Loan to Employee</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Owner Draw</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="divider"></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">Customise Categories</a>
                                                                                    </li>
                                                                                </ul>
                                                                            </li>
                                                                            <li class="dropdown-submenu">
                                                                                <a class="ellipsis-block" role="button">
                                                                                    <div class="A54VNK-nh-c">
                                                                                        <div class="A54VNK-nh-e">
                                                                                            <div class="A54VNK-nh-d" style="background-color: rgb(181, 69, 14);">
                                                                                            </div>
                                                                                            <div>
                                                                                                <div>Rent and Maintenance</div>
                                                                                            </div>
                                                                                        </div>
                                                                                        <span class="picto-font A54VNK-nh-f"></span>
                                                                                    </div>
                                                                                </a>
                                                                                <ul class="dropdown-menu">
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Building Maintenance</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Business Rent or Lease</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Other Rent</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="divider"></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">Customise Categories</a>
                                                                                    </li>
                                                                                </ul>
                                                                            </li>
                                                                            <li class="dropdown-submenu">
                                                                                <a class="ellipsis-block" role="button">
                                                                                    <div class="A54VNK-nh-c">
                                                                                        <div class="A54VNK-nh-e">
                                                                                            <div class="A54VNK-nh-d" style="background-color: rgb(138, 25, 134);">
                                                                                            </div>
                                                                                            <div>
                                                                                                <div>Services</div>
                                                                                            </div>
                                                                                        </div>
                                                                                        <span class="picto-font A54VNK-nh-f"></span>
                                                                                    </div>
                                                                                </a>
                                                                                <ul class="dropdown-menu">
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Accounting Services</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Commissions and Fees</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Legal Services</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Professional Services</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Retrocession fees</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="divider"></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">Customise Categories</a>
                                                                                    </li>
                                                                                </ul>
                                                                            </li>
                                                                            <li class="dropdown-submenu">
                                                                                <a class="ellipsis-block" role="button">
                                                                                    <div class="A54VNK-nh-c">
                                                                                        <div class="A54VNK-nh-e">
                                                                                            <div class="A54VNK-nh-d" style="background-color: rgb(64, 105, 156);">
                                                                                            </div>
                                                                                            <div>
                                                                                                <div>Supplier Payments</div>
                                                                                            </div>
                                                                                        </div>
                                                                                        <span class="picto-font A54VNK-nh-f"></span>
                                                                                    </div>
                                                                                </a>
                                                                                <ul class="dropdown-menu">
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>ATM / Cash Withdrawal</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Delivery or Freight Paid</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Freelance / Contractor Compensation</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Other Costs</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Other Supplier Payments</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Pay Supplier Bill</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Unknown Cheque Payment</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="divider"></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">Customise Categories</a>
                                                                                    </li>
                                                                                </ul>
                                                                            </li>
                                                                            <li class="dropdown-submenu">
                                                                                <a class="ellipsis-block" role="button">
                                                                                    <div class="A54VNK-nh-c">
                                                                                        <div class="A54VNK-nh-e">
                                                                                            <div class="A54VNK-nh-d" style="background-color: rgb(140, 103, 38);">
                                                                                            </div>
                                                                                            <div>
                                                                                                <div>Taxes</div>
                                                                                            </div>
                                                                                        </div>
                                                                                        <span class="picto-font A54VNK-nh-f"></span>
                                                                                    </div>
                                                                                </a>
                                                                                <ul class="dropdown-menu">
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Business Tax</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Company value-added contribution</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Other Tax</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Penalties and Fines</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Property Tax</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>VAT Payment</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="divider"></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">Customise Categories</a>
                                                                                    </li>
                                                                                </ul>
                                                                            </li>
                                                                            <li class="dropdown-submenu">
                                                                                <a class="ellipsis-block" role="button">
                                                                                    <div class="A54VNK-nh-c">
                                                                                        <div class="A54VNK-nh-e">
                                                                                            <div class="A54VNK-nh-d" style="background-color: rgb(63, 81, 181);">
                                                                                            </div>
                                                                                            <div>
                                                                                                <div>Travel / Meals / Entertainment</div>
                                                                                            </div>
                                                                                        </div>
                                                                                        <span class="picto-font A54VNK-nh-f"></span>
                                                                                    </div>
                                                                                </a>
                                                                                <ul class="dropdown-menu">
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Fuel</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Mileage Expense</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Parking</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Public transport</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Reimbursement for Employee Expense</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Taxi</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Tolls</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Travel Expenses</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Vehicle Maintenance</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Working Meals</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="divider"></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">Customise Categories</a>
                                                                                    </li>
                                                                                </ul>
                                                                            </li>
                                                                            <li class="dropdown-submenu">
                                                                                <a class="ellipsis-block" role="button">
                                                                                    <div class="A54VNK-nh-c">
                                                                                        <div class="A54VNK-nh-e">
                                                                                            <div class="A54VNK-nh-d" style="background-color: rgb(103, 58, 183);">
                                                                                            </div>
                                                                                            <div>
                                                                                                <div>Utilities</div>
                                                                                            </div>
                                                                                        </div>
                                                                                        <span class="picto-font A54VNK-nh-f"></span>
                                                                                    </div>
                                                                                </a>
                                                                                <ul class="dropdown-menu">
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Business Administration</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Charitable Contributions</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Charity and Gifts</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Entertainment</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Equipment Repair</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Gas</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Gifts to Customers or Suppliers</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Maintenance</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Other Utilities</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Power</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Waste Management</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Water</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="divider"></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">Customise Categories</a>
                                                                                    </li>
                                                                                </ul>
                                                                            </li>
                                                                            <li class="dropdown-header" style="margin-top: 8px;">REFUND</li>
                                                                            <li class="dropdown-submenu">
                                                                                <a class="ellipsis-block" role="button">
                                                                                    <div class="A54VNK-nh-c">
                                                                                        <div class="A54VNK-nh-e">
                                                                                            <div class="A54VNK-nh-d" style="background-color: rgb(2, 113, 93);"></div>
                                                                                            <div>
                                                                                                <div>Financial Income</div>
                                                                                            </div>
                                                                                        </div>
                                                                                        <span class="picto-font A54VNK-nh-f"></span>
                                                                                    </div>
                                                                                </a>
                                                                                <ul class="dropdown-menu">
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Grant Income</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Interest Income</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Investment Income</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Other Financial Income</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="divider"></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">Customise Categories</a>
                                                                                    </li>
                                                                                </ul>
                                                                            </li>
                                                                            <li class="dropdown-submenu">
                                                                                <a class="ellipsis-block" role="button">
                                                                                    <div class="A54VNK-nh-c">
                                                                                        <div class="A54VNK-nh-e">
                                                                                            <div class="A54VNK-nh-d" style="background-color: rgb(2, 109, 6);"></div>
                                                                                            <div>
                                                                                                <div>Income</div>
                                                                                            </div>
                                                                                        </div>
                                                                                        <span class="picto-font A54VNK-nh-f"></span>
                                                                                    </div>
                                                                                </a>
                                                                                <ul class="dropdown-menu">
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Customer Payment for invoice</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Late Income Penalties</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Other Income</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Pre-payment from a Customer</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Shipping or Delivery Fee Collected</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="divider"></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">Customise Categories</a>
                                                                                    </li>
                                                                                </ul>
                                                                            </li>
                                                                            <li class="dropdown-submenu">
                                                                                <a class="ellipsis-block" role="button">
                                                                                    <div class="A54VNK-nh-c">
                                                                                        <div class="A54VNK-nh-e">
                                                                                            <div class="A54VNK-nh-d" style="background-color: rgb(11, 103, 107);">
                                                                                            </div>
                                                                                            <div>
                                                                                                <div>Miscellaneous Deposits</div>
                                                                                            </div>
                                                                                        </div>
                                                                                        <span class="picto-font A54VNK-nh-f"></span>
                                                                                    </div>
                                                                                </a>
                                                                                <ul class="dropdown-menu">
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Income from Rent</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Loan Principal - Received</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Other Deposits</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Owner Deposit to Business Bank Account</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Partner Deposit to Business Bank Account</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Payments Received from Employee Loans</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Startup Capital</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="divider"></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">Customise Categories</a>
                                                                                    </li>
                                                                                </ul>
                                                                            </li>
                                                                            <li class="dropdown-submenu">
                                                                                <a class="ellipsis-block" role="button">
                                                                                    <div class="A54VNK-nh-c">
                                                                                        <div class="A54VNK-nh-e">
                                                                                            <div class="A54VNK-nh-d" style="background-color: rgb(72, 72, 72);"></div>
                                                                                            <div>
                                                                                                <div>Sales</div>
                                                                                            </div>
                                                                                        </div>
                                                                                        <span class="picto-font A54VNK-nh-f"></span>
                                                                                    </div>
                                                                                </a>
                                                                                <ul class="dropdown-menu">
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Sales - Other</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Sales - Products</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">
                                                                                            <div class="A54VNK-nh-c">
                                                                                                <div class="A54VNK-nh-e">
                                                                                                    <div>
                                                                                                        <div>Sales - Services</div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </a></li>
                                                                                    <li class="divider"></li>
                                                                                    <li class="">
                                                                                        <a class="ellipsis-block" role="button">Customise Categories</a>
                                                                                    </li>
                                                                                </ul>
                                                                            </li>
                                                                        </ul>

                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-12 col-sm-2 object-list-cell">
                                                                <div class="form-group floating-label">
                                                                    <input type="text" class="form-control form-component" id="gwt-uid-2129" autocomplete="off">
                                                                    <label class="control-label form-question ellipsis" for="gwt-uid-2129">Before VAT</label>

                                                                </div>
                                                            </div>
                                                            <div class="col-12 col-sm-2 object-list-cell">
                                                                <div class="form-group floating-label focused">
                                                                    <div class="dropdown form-component">
                                                                        <input type="text" class="form-control A54VNK-ie-i" id="gwt-uid-2125" data-toggle="dropdown" autocomplete="off">
                                                                        <label class="control-label form-question ellipsis" style="transform: translateY(6px);" for="gwt-uid-2125">VAT</label>
                                                                        <ul class="dropdown-menu A54VNK-ie-d">
                                                                            <li class="active">
                                                                                <a class="ellipsis-block" role="button">None</a>
                                                                            </li>
                                                                            <li class="">
                                                                                <a class="ellipsis-block" role="button">20.0% Standard rate
                                                                                                                        (Deductible)</a>
                                                                            </li>
                                                                            <li class="">
                                                                                <a class="ellipsis-block" role="button">5.0% Lower rate
                                                                                                                        (Deductible)</a>
                                                                            </li>
                                                                            <li class="">
                                                                                <a class="ellipsis-block" role="button">0.0% Zero-rated
                                                                                                                        (Deductible)</a>
                                                                            </li>
                                                                            <li class="">
                                                                                <a class="ellipsis-block" role="button">0.0% Exempt (Deductible)</a>
                                                                            </li>
                                                                        </ul>

                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-12 col-sm-2 object-list-cell">
                                                                <div class="form-group floating-label">
                                                                    <input type="text" class="form-control form-component" id="gwt-uid-2133" autocomplete="off">
                                                                    <label class="control-label form-question ellipsis" for="gwt-uid-2133">Amount + VAT</label>

                                                                </div>
                                                            </div>
                                                            <div class="col-12 col-sm-3 object-list-last-cell">
                                                                <div class="form-group floating-label form-group-textarea">
                                                                    <textarea class="form-control form-component A54VNK-Cb-b" style="height: 48px;" id="gwt-uid-2115" autocomplete="off" rows="1"></textarea>
                                                                    <label class="control-label form-question ellipsis" for="gwt-uid-2115">Notes</label>

                                                                </div>
                                                            </div>
                                                            <div class="col-12 col-sm-1 text-right object-list-last-cell" aria-hidden="true"
                                                                 style="display: none;">
                                                                <button type="button" class="btn btn-danger A54VNK-Mi-a"
                                                                        aria-hidden="true" style="display: none;">
                                                                    <span class="picto-font">#</span></button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <button type="button" class="btn btn-default A54VNK-If-a">Add a split</button>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                            <div class="row A54VNK-qf-b">
                                <div class="col-5 col-sm-2" aria-hidden="true" style="display: none;">
                                    <div class="form-group floating-label focused">
                                        <div class="select-panel form-component">
                                            <select class="form-control" id="gwt-uid-2085">
                                                <option value="BDT">BDT</option>
                                            </select>
                                            <label class="control-label form-question ellipsis" for="gwt-uid-2085">Currency</label>
                                        </div>

                                    </div>
                                </div>

                                <div class="col-7 col-sm-2 text-right A54VNK-qf-c"><label>TOTAL: Tk0.00</label></div>
                            </div>
                            <hr>
                            <h4> Payment </h4>
                            <div class="row A54VNK-qf-a">
                                <div class="col-12 col-sm-4 form-group">
                                    <div class="btn-group btn-group-toggle" style="width: 100%;" aria-atomic="true" tabindex="0">
                                        <a class="btn btn-default" href="#" aria-pressed="false" role="button">Unpaid</a>
                                        <a class="btn active btn-primary" href="#" aria-pressed="true" role="button">Paid</a>
                                    </div>
                                </div>
                                <div class="col-12 col-sm-4">
                                    <div class="form-group floating-label focused">
                                        <div class="select-panel form-component">
                                            <select class="form-control" id="gwt-uid-400">
                                                <option value="check">Cheque</option>
                                                <option value="debit_credit_card">Debit/Credit Card</option>
                                                <option value="cash">Cash</option>
                                                <option value="direct_debit_ach">Direct Debit/ACH</option>
                                                <option value="wire_transfer">Wire Transfer</option>
                                                <option value="other">Other</option>
                                                <option value="gift_certificate">Gift Certificate</option>
                                                <option value="credit_note">Credit Note</option>
                                            </select>
                                            <label class="control-label form-question ellipsis" for="gwt-uid-400">Payment method</label>

                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 col-sm-4">
                                    <div class="form-group floating-label mandatory focused">
                                        <div class="form-component A54VNK-pd-c">
                                            <input type="text" class="form-control" id="gwt-uid-2172">
                                            <label class="control-label form-question ellipsis" style="transform: translateY(6px);" for="gwt-uid-2172">Paid on</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="collapse in A54VNK-qf-d">
                                <div class="row">
                                    <div class="col-12 col-sm-4">
                                        <div class="form-group floating-label mandatory">
                                            <div class="dropdown form-component">
                                                <input type="text" class="form-control A54VNK-ie-i" id="gwt-uid-2164" data-toggle="dropdown" autocomplete="off">
                                                <label class="control-label form-question ellipsis" for="gwt-uid-2164">Bank</label>
                                                <ul class="dropdown-menu A54VNK-ie-d">
                                                    <li class="disabled"><a> No result </a></li>
                                                    <li class="divider"></li>
                                                    <li class="active">
                                                        <a class="ellipsis-block" role="button">New Bank</a></li>
                                                </ul>

                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12 col-sm-4">
                                        <div class="form-group floating-label">
                                            <input type="text" class="form-control form-component" id="gwt-uid-2180" autocomplete="off">
                                            <label class="control-label form-question ellipsis" for="gwt-uid-2180">Transaction Id</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-sm-12 A54VNK-qi-c">
                                    <h4> Attachments </h4>
                                </div>
                                <div class="container-fluid">
                                    <div class="row A54VNK-qi-a" id="dvPreview">
                                        <div class="col-12 col-sm-4 col-md-3 A54VNK-kh-b">
                                            <div class="A54VNK-kh-a">
                                                <div class="A54VNK-kh-g">
                                                    <img class="img-responsive">
                                                </div>
                                                <div class="A54VNK-kh-e">
                                                    <div class="ellipsis-block A54VNK-kh-f bolder">image.name</div>
                                                    <div class="small text-muted">Added on imagedate</div>
                                                </div>
                                            </div>
                                            <button type="button" class="A54VNK-kh-c" title="Delete">×</button>
                                        </div>
                                    </div>
                                    <div class="A54VNK-Ri-b">
                                        <div class="A54VNK-Ri-e">
                                            <div class="picto-font A54VNK-Ri-d drap_mob_none"></div>
                                            <div class="drap_mob_none"> Drag files to attach , or</div>
                                            <label for="upload-photo" class="btn btn-link A54VNK-Ri-a" style="margin-bottom: 0;padding-top: 6px;padding-left: 0;padding-bottom: 0;text-transform: capitalize;">Browse files from your device</label>
                                        </div>
                                        <div class="text-muted A54VNK-Ri-c"> or</div>
                                        <label class="btn btn-default" for="upload-photo" style="margin-bottom: 0;text-transform: capitalize;font-weight: 400;">Browse uploaded files</label>
                                        <input type="file" name="photo" id="upload-photo" multiple="multiple" style="opacity: 0;position: absolute;z-index: -1;">
                                    </div>
                                </div>
                            </div>
                            <div>
                                <hr>
                                <h4> Other Details </h4>
                                <div class="row">
                                    <div class="col-12 col-sm-4">
                                        <div class="form-group floating-label">
                                            <div class="dropdown form-component">
                                                <input type="text" class="form-control A54VNK-ie-i" id="gwt-uid-2190" data-toggle="dropdown" autocomplete="off">
                                                <label class="control-label form-question ellipsis" for="gwt-uid-2190">Project</label>
                                                <ul class="dropdown-menu A54VNK-ie-d">
                                                    <li class="active">
                                                        <a class="ellipsis-block" role="button">View all Projects</a>
                                                    </li>
                                                    <li class="divider"></li>
                                                    <li class="">
                                                        <a class="ellipsis-block" role="button">Create a Project</a>
                                                    </li>
                                                </ul>

                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12 col-sm-4">
                                        <div class="form-group floating-label focused" aria-hidden="true" style="display: none;">
                                            <div class="select-panel form-component">
                                                <select class="form-control" id="gwt-uid-2196">
                                                    <option value="102228">Yasir intu</option>
                                                </select>
                                                <label class="control-label form-question ellipsis" for="gwt-uid-2196">Assigned
                                                                                                                       To</label>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <new-footer type="basic"/>
                </div>
            </div>
        </div>
    </form>

    <!-- form section -->
</template>

<script>
    import NewFooter from '../../../layouts/partials/new_footer'

    export default {
        components: {
            NewFooter,
        },
        name: 'Expense',
        data: function () {
            return {
                loaded: false,
                form: new Form({
                    "id": "",
                    "paid_to": "",
                    "billing_date": "",
                    "category": "",
                    "currency": "",
                    "is_paid": "",
                    "payment_method": "",
                    "paid_on": "",
                    "bank": "",
                    "transaction_id": "",
                    "attachments": "",
                    "project": "",
                    "assigned": "",
                    "created_at": "",
                    "updated_at": "",
                })
            }
        },
        created: function () {
            this.getExpense();
        },
        methods: {
            getExpense: function (Expense) {

                var that = this;
                this.form.get('/api/expenses/' + this.$route.params.id).then(function (response) {
                    that.form.fill(response.data);
                    that.loaded = true;
                });

            },
            updateExpense: function () {

                var that = this;
                this.form.put('/api/expenses/' + this.$route.params.id).then(function (response) {
                    that.form.fill(response.data);
                })

            },
            deleteExpense: function () {

                var that = this;
                this.form.delete('/api/expenses/' + this.$route.params.id).then(function (response) {
                    that.form.fill(response.data);
                    that.$router.push('/super-admin/expenses');
                })

            }
        }
    }
</script>
