<template>
    <!-- form section -->

    <form>
        <div class="right-content form1">
            <div id="contentRootPanel" class="fullpage">
                <div class="A54VNK-ce-a">
                    <div class="page-panel panel-default page-right-content">
                        <div>
                            <div class="panel-body page-panel-body">
                                <div>
                                    <div>
                                        <div>
                                            <div class="row">
                                                <div class="col-sm-6">
                                                    <div>
                                                        <div>
                                                            <div class="form-horizontal">
                                                                <div class="form-group row">
                                                                    <div class="col-sm-4 col-4 control-label">
                                                                        <label class="" style="font-weight: normal;">Supplier</label>
                                                                        <span class="text-danger bold">*</span>
                                                                    </div>
                                                                    <div class="col-sm-8 col-8">
                                                                        <div class="dropdown">
                                                                            <a class="A54VNK-pi-a" style="">
                                                                                <span class="picto-font">D</span>
                                                                            </a>
                                                                            <input type="text" class="form-control A54VNK-pi-d" data-toggle="dropdown" autocomplete="off" role="button" placeholder="supplier name or code" aria-expanded="true">
                                                                            <ul class="dropdown-menu A54VNK-pi-c">
                                                                                <li class="active">
                                                                                    <a class="ellipsis-block" role="button">supplier.company_name</a>
                                                                                    <a class="ellipsis-block" role="button">supplier.first_name supplier.last_name</a>
                                                                                </li>
                                                                                <li class="active">
                                                                                    <a class="ellipsis-block" role="button">View all Leads and suppliers</a>
                                                                                </li>
                                                                                <li class="">
                                                                                    <a class="ellipsis-block" role="button">Create a Lead or supplier</a>
                                                                                </li>
                                                                            </ul>
                                                                        </div>

                                                                    </div>
                                                                </div>
                                                                <div class="form-group row">
                                                                    <div class="col-sm-4 col-4 control-label">
                                                                        <label class="" style="font-weight: normal;">Recipient</label>
                                                                    </div>
                                                                    <div class="col-sm-8 col-8">
                                                                        <div class="A54VNK-ni-a">
                                                                            <div class="select-panel A54VNK-ni-c">
                                                                                <select class="form-control" size="1">
                                                                                    <option value="0">None</option>
                                                                                </select>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group row">
                                                                    <div class="col-sm-4 col-4 control-label">
                                                                        <label class="" style="font-weight: normal;">Address</label>
                                                                    </div>
                                                                    <div class="col-sm-8 col-8">
                                                                        <textarea class="form-control" rows="4" disabled="" style="resize: vertical; min-height: 50px;"></textarea>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group row">
                                                                    <div class="col-sm-4 col-4 control-label">
                                                                        <label class="" style="font-weight: normal;">Currency</label>
                                                                    </div>
                                                                    <div class="col-sm-8 col-8">
                                                                        <div class="A54VNK-ni-a">
                                                                            <div class="select-panel A54VNK-ni-c">
                                                                                <select class="form-control" size="1">
                                                                                    <option>currency.exchange_currency</option>
                                                                                </select>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <hr>
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div>
                                                        <div>
                                                            <div class="form-horizontal">
                                                                <div class="form-group row">
                                                                    <div class="col-sm-4 col-4 control-label">
                                                                        <label class="" style="font-weight: normal;">Code</label>
                                                                        <span class="text-danger bold" aria-hidden="true">*</span>
                                                                    </div>
                                                                    <div class="col-sm-8 col-8">
                                                                        <div class="dropdown">
                                                                            <input type="text" class="form-control A54VNK-oi-b" autocomplete="off" placeholder="code">
                                                                        </div>
                                                                        <div class="error-panel"></div>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group row">
                                                                    <div class="col-sm-4 col-4 control-label">
                                                                        <label class="" style="font-weight: normal;">Ref Number</label>
                                                                    </div>
                                                                    <div class="col-sm-8 col-8">
                                                                        <input type="text" class="form-control A54VNK-oi-b" autocomplete="off">
                                                                    </div>
                                                                </div>
                                                                <div class="form-group row">
                                                                    <div class="col-sm-4 col-4 control-label">
                                                                        <label class="" style="font-weight: normal;">Date</label>
                                                                        <span class="text-danger bold">*</span>
                                                                    </div>
                                                                    <div class="col-sm-8 col-8">
                                                                        <div class="input-group">
                                                                            <input type="text" class="form-control">
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group row">
                                                                    <div class="col-sm-4 col-4 control-label">
                                                                        <label class="" style="font-weight: normal;">Status</label>
                                                                    </div>
                                                                    <div class="col-sm-8 col-8">
                                                                        <div class="A54VNK-ni-a">
                                                                            <div class="select-panel A54VNK-ni-c">
                                                                                <select class="form-control" size="1">
                                                                                    <option value="3">Lost</option>
                                                                                    <option value="1">Open</option>
                                                                                    <option value="2">Won</option>
                                                                                </select>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group row">
                                                                    <div class="col-sm-4 col-4 control-label">
                                                                        <label class="" style="font-weight: normal;">Delivery Date</label>
                                                                        <span class="text-danger bold">*</span></div>
                                                                    <div class="col-sm-8 col-8">
                                                                        <div class="input-group">
                                                                            <input type="text" class="form-control">
                                                                        </div>
                                                                        <div class="error-panel"></div>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group row">
                                                                    <div class="col-sm-4 col-4 control-label">
                                                                        <label class="" style="font-weight: normal;">Payment Terms</label>
                                                                    </div>
                                                                    <div class="col-sm-8 col-8">
                                                                        <div class="dropdown">
                                                                            <input type="text" class="form-control A54VNK-oi-b" data-toggle="dropdown" autocomplete="off" role="button" placeholder="Search results">
                                                                            <ul class="dropdown-menu A54VNK-oi-a">
                                                                                <li class="active"><a class="ellipsis-block" role="button" title="Due on receipt"><strong>Due</strong> <strong>on</strong> <strong>receipt</strong></a></li>
                                                                                <li class="divider"></li>
                                                                                <li class=""><a class="ellipsis-block" role="button">Start the search</a></li>
                                                                                <li class=""><a class="ellipsis-block" role="button">Create a new...</a></li>
                                                                            </ul>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <hr>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div>
                                        <div>
                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <div>
                                                        <div>
                                                            <div>
                                                                <table class="A54VNK-Ff-y table table-hover table-link A54VNK-Ff-z empty" cellspacing="0" style="table-layout: fixed;">
                                                                    <colgroup>
                                                                        <col style="width: 15%;">
                                                                        <col style="width: 25%;">
                                                                        <col style="width: 80%;">
                                                                        <col style="width: 20%;">
                                                                        <col style="width: 25%;">
                                                                        <col style="width: 20%;">
                                                                        <col style="width: 30%;">
                                                                        <col style="width: 25%;">
                                                                    </colgroup>
                                                                    <thead>
                                                                        <tr>
                                                                            <th colspan="1" class="A54VNK-Ff-h A54VNK-Ff-f">
                                                                                <div>
                                                                                    <span class="ellipsis ellipsis-block header-small" data-title="" data-toggle="tooltip"></span>
                                                                                    <span class="header-normal"></span>
                                                                                </div>
                                                                            </th>
                                                                            <th colspan="1" class="A54VNK-Ff-h">
                                                                                <div>
                                                                                    <span class="ellipsis ellipsis-block header-small" data-title="" data-toggle="tooltip"></span>
                                                                                    <span class="header-normal"></span>
                                                                                </div>
                                                                            </th>
                                                                            <th colspan="1" class="A54VNK-Ff-h">
                                                                                <div>
                                                                                    <span class="ellipsis ellipsis-block header-small" data-title="Description" data-toggle="tooltip">Description</span>
                                                                                    <span class="header-normal">Description</span>
                                                                                </div>
                                                                            </th>
                                                                            <th colspan="1" class="A54VNK-Ff-h">
                                                                                <div>
                                                                                    <span class="ellipsis ellipsis-block header-small" data-title="Qty" data-toggle="tooltip">Qty</span>
                                                                                    <span class="header-normal">Qty</span>
                                                                                </div>
                                                                            </th>
                                                                            <th colspan="1" class="A54VNK-Ff-h">
                                                                                <div>
                                                                                    <span class="ellipsis ellipsis-block header-small" data-title="Price	" data-toggle="tooltip">Price </span>
                                                                                    <span class="header-normal">Price </span>
                                                                                </div>
                                                                            </th>
                                                                            <th colspan="1" class="A54VNK-Ff-h">
                                                                                <div>
                                                                                    <span class="ellipsis ellipsis-block header-small" data-title="Disc.%" data-toggle="tooltip">Disc.%</span>
                                                                                    <span class="header-normal">Disc.%</span>
                                                                                </div>
                                                                            </th>
                                                                            <th colspan="1" class="A54VNK-Ff-h">
                                                                                <div>
                                                                                    <span class="ellipsis ellipsis-block header-small" data-title="Total" data-toggle="tooltip">Total</span>
                                                                                    <span class="header-normal">Total</span>
                                                                                </div>
                                                                            </th>
                                                                            <th colspan="1" class="A54VNK-Ff-h A54VNK-Ff-p">
                                                                                <div>
                                                                                    <span class="ellipsis ellipsis-block header-small" data-title="VAT%" data-toggle="tooltip">VAT%</span>
                                                                                    <span class="header-normal">VAT%</span>
                                                                                </div>
                                                                            </th>
                                                                        </tr>
                                                                    </thead>
                                                                    <tbody>
                                                                        <tr class="A54VNK-Ff-r">
                                                                            <td class="A54VNK-Ff-a A54VNK-Ff-s A54VNK-Ff-d">
                                                                                <div style="outline-style:none;">123</div>
                                                                            </td>
                                                                            <td class="A54VNK-Ff-a A54VNK-Ff-s">
                                                                                <div style="outline-style:none;">123</div>
                                                                            </td>
                                                                            <td class="A54VNK-Ff-a A54VNK-Ff-s">
                                                                                <div style="outline-style:none;">
                                                                                    <textarea class="form-control" rows="1"></textarea>
                                                                                </div>
                                                                            </td>
                                                                            <td class="A54VNK-Ff-a A54VNK-Ff-s">
                                                                                <div style="outline-style:none;">
                                                                                    <input type="text" class="form-control">
                                                                                </div>
                                                                            </td>
                                                                            <td class="A54VNK-Ff-a A54VNK-Ff-s">
                                                                                <div style="outline-style:none;">
                                                                                    <input type="text" class="form-control">
                                                                                </div>
                                                                            </td>
                                                                            <td class="A54VNK-Ff-a A54VNK-Ff-s">
                                                                                <div style="outline-style:none;">
                                                                                    <input type="text" class="form-control">
                                                                                </div>
                                                                            </td>
                                                                            <td class="A54VNK-Ff-a A54VNK-Ff-s A54VNK-Ff-A">
                                                                                <div style="outline-style:none;">123</div>
                                                                            </td>
                                                                            <td class="A54VNK-Ff-a A54VNK-Ff-s A54VNK-Ff-n">
                                                                                <div style="outline-style:none;">
                                                                                    <div class="dropdown">
                                                                                        <input type="text" class="form-control A54VNK-Yj-b" placeholder="Search results" data-toggle="dropdown" autocomplete="off">
                                                                                        <ul class="dropdown-menu A54VNK-Yj-a">
                                                                                            <li class="">
                                                                                                <a class="ellipsis-block" role="button">0.0% Vat</a>
                                                                                            </li>
                                                                                            <li class="">
                                                                                                <a class="ellipsis-block" role="button">tax.tax_rate% tax.tax_name</a>
                                                                                            </li>
                                                                                        </ul>
                                                                                    </div>
                                                                                </div>
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                    <tbody>
                                                                        <tr>
                                                                            <td align="center" colspan="8">
                                                                                <div>
                                                                                    <div style="width: 100%; height: 100%; padding: 0px; margin: 0px;">
                                                                                        <div style="width: 100%; height: 100%;">
                                                                                            <div class="text-muted text-left">No items to show</div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div aria-hidden="true" style="width: 100%; height: 100%; padding: 0px; margin: 0px; display: none;">
                                                                                        <div aria-hidden="true" class="A54VNK-Ff-q" style="width: 100%; height: 100%; display: none;">
                                                                                            <div class="text-muted text-left">Loading data...</div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                        </div>
                                                        <div class="btn-toolbar A54VNK-Ki-a">
                                                            <button type="button" class="btn btn-default mt-2">
                                                                <span class="picto-font">s</span> Add Product or Service
                                                            </button>
                                                            <button type="button" class="btn btn-default ml-2 mt-2">
                                                                <span class="picto-font">-</span> Delete
                                                            </button>
                                                            <button type="button" class="btn btn-default ml-2 mt-2" disabled>
                                                                <span class="picto-font"></span>
                                                            </button>
                                                            <button type="button" class="btn btn-default ml-2 mt-2">
                                                                <span class="picto-font"></span>
                                                            </button>
                                                            <button type="button" class="btn btn-default ml-2 mt-2" disabled>
                                                                <span class="picto-font"></span>
                                                            </button>
                                                            <button type="button" class="btn btn-default ml-2 mt-2">
                                                                <span class="picto-font"></span>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div>
                                        <div>
                                            <div class="row">
                                                <div class="col-sm-6">
                                                    <div>
                                                        <div>
                                                            <div class="form-horizontal">
                                                                <div class="form-group row" style="margin-bottom: 15px !important;">
                                                                    <div class="col-sm-4 col-4 control-label">
                                                                        <label class="" style="font-weight: normal;">Document Note</label>

                                                                    </div>
                                                                    <div class="col-sm-8 col-8">
                                                                        <textarea class="form-control" rows="3" style="resize: vertical; min-height: 50px;"></textarea>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <hr>
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div>
                                                        <div>
                                                            <div class="row">
                                                                <div class="col-sm-12">
                                                                    <div>
                                                                        <div>
                                                                            <div class="form-horizontal">
                                                                                <div class="form-group row" style="margin-bottom: 15px !important;">
                                                                                    <div class="col-sm-4 col-4 control-label">
                                                                                        <label class="" style="font-weight: normal;">Subtotal</label>

                                                                                    </div>
                                                                                    <div class="col-sm-8 col-8">
                                                                                        <input type="text" class="form-control" disabled="" style="text-align: right;">
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <hr>
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-12">
                                                                    <div>
                                                                        <div>
                                                                            <div class="form-horizontal">
                                                                                <div class="form-group row" style="margin-bottom: 15px !important;">
                                                                                    <div class="col-sm-4 col-4 control-label">
                                                                                        <label class="" style="font-weight: normal;">Discount Rate</label>

                                                                                    </div>
                                                                                    <div class="col-sm-8 col-8">
                                                                                        <input type="text" class="form-control" style="text-align: right;">
                                                                                    </div>
                                                                                </div>
                                                                                <div class="form-group row" style="margin-bottom: 15px !important;">
                                                                                    <div class="col-sm-4 col-4 control-label">
                                                                                        <label class="" style="font-weight: normal;">Discount Amount</label>

                                                                                    </div>
                                                                                    <div class="col-sm-8 col-8">
                                                                                        <input type="text" class="form-control" disabled="" style="text-align: right;">
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <hr>
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-12">
                                                                    <div>
                                                                        <div>
                                                                            <div class="form-horizontal">
                                                                                <div class="form-group row" style="margin-bottom: 15px !important;">
                                                                                    <div class="col-sm-4 col-4 control-label">
                                                                                        <label class="" style="font-weight: normal;">VAT</label>

                                                                                    </div>
                                                                                    <div class="col-sm-8 col-8">
                                                                                        <input type="text" class="form-control" disabled="" style="text-align: right;">
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <hr>
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-12">
                                                                    <div>
                                                                        <div>
                                                                            <div class="form-horizontal">
                                                                                <div class="form-group row" style="margin-bottom: 15px !important;">
                                                                                    <div class="col-sm-4 col-4 control-label">
                                                                                        <label class="" style="font-weight: normal;">Total</label>
                                                                                    </div>
                                                                                    <div class="col-sm-8 col-8">
                                                                                        <input type="text" class="form-control" disabled="" style="text-align: right;">
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <hr>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div>
                                        <div>
                                            <a class="accordion-toggle collapsed A54VNK-ri-a" data-toggle="collapse" href="#gwt-uid-637">Advanced</a>
                                            <div class="panel-collapse collapse" id="gwt-uid-637">
                                                <div class="panel-body">
                                                    <div>
                                                        <div>
                                                            <div class="row">
                                                                <div class="col-sm-12">
                                                                    <div>
                                                                        <div>
                                                                            <div class="form-horizontal">
                                                                                <div class="form-group row" style="margin-bottom: 15px !important;">
                                                                                    <div class="col-sm-4 col-4 control-label">
                                                                                        <label class="" style="font-weight: normal;">Delivery Contact</label></div>
                                                                                    <div class="col-sm-8 col-8">
                                                                                        <div class="dropdown">
                                                                                            <a class="A54VNK-pi-a" style="">
                                                                                                <span class="picto-font">D</span>
                                                                                            </a>
                                                                                            <input type="text" class="form-control A54VNK-pi-d" data-toggle="dropdown" autocomplete="off" role="button" placeholder="Contact name">
                                                                                            <ul class="dropdown-menu A54VNK-pi-c">
                                                                                                <li class="disabled"><a> No result </a></li>
                                                                                                <li class="divider"></li>
                                                                                            </ul>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="form-group row" style="margin-bottom: 15px !important;">
                                                                                    <div class="col-sm-4 col-4 control-label">
                                                                                        <label class="" style="font-weight: normal;">Delivery Address</label>
                                                                                    </div>
                                                                                    <div class="col-sm-8 col-8">
                                                                                        <div class="dropdown">
                                                                                            <a class="A54VNK-pi-a" style="">
                                                                                                <span class="picto-font">D</span>
                                                                                            </a>
                                                                                            <input type="text" class="form-control A54VNK-pi-d" data-toggle="dropdown" autocomplete="off" role="button" placeholder="Contact address">
                                                                                            <ul class="dropdown-menu A54VNK-pi-c">
                                                                                                <li class="disabled"><a> No result </a></li>
                                                                                                <li class="divider"></li>
                                                                                            </ul>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <hr>
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-12">
                                                                    <div>
                                                                        <div>
                                                                            <div class="form-horizontal">
                                                                                <div class="form-group row" style="margin-bottom: 15px !important;">
                                                                                    <div class="col-sm-4 col-4 control-label">
                                                                                        <label class="" style="font-weight: normal;">Project</label>

                                                                                    </div>
                                                                                    <div class="col-sm-8 col-8">
                                                                                        <div class="dropdown">
                                                                                            <a class="A54VNK-pi-a" style="">
                                                                                                <span class="picto-font">D</span>
                                                                                            </a>
                                                                                            <input type="text" class="form-control A54VNK-pi-d" data-toggle="dropdown" autocomplete="off" role="button" placeholder="Project name">
                                                                                            <ul class="dropdown-menu A54VNK-pi-c">
                                                                                                <li class="disabled"><a> No result </a></li>
                                                                                                <li class="divider"></li>
                                                                                            </ul>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <hr>
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-12">
                                                                    <div>
                                                                        <div>
                                                                            <div class="form-horizontal">
                                                                                <div class="form-group row" style="margin-bottom: 15px !important;">
                                                                                    <div class="col-sm-4 col-4 control-label">
                                                                                        <label class="" style="font-weight: normal;">Assigned To</label>
                                                                                    </div>
                                                                                    <div class="col-sm-8 col-8">
                                                                                        <div class="dropdown">
                                                                                            <a class="A54VNK-pi-a" style="">
                                                                                                <span class="picto-font">D</span>
                                                                                            </a>
                                                                                            <input type="text" class="form-control A54VNK-pi-d" data-toggle="dropdown" autocomplete="off" role="button" placeholder="Assigned To">
                                                                                            <ul class="dropdown-menu A54VNK-pi-c">
                                                                                                <li class="disabled"><a> No result </a></li>
                                                                                                <li class="divider"></li>
                                                                                            </ul>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <hr>
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-12">
                                                                    <div>
                                                                        <div>
                                                                            <div class="form-horizontal">
                                                                                <div class="form-group row" style="margin-bottom: 15px !important;">
                                                                                    <div class="col-sm-4 col-4 control-label">
                                                                                        <label class="" style="font-weight: normal;">Private Note</label>
                                                                                    </div>
                                                                                    <div class="col-sm-8 col-8">
                                                                                        <textarea class="form-control" rows="3" style="resize: vertical; min-height: 50px;"></textarea>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <hr>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <new-footer type="basic"/>
                </div>
            </div>
        </div>
    </form>

    <!-- form section -->
</template>

<script>
    import NewFooter from '../../../layouts/partials/new_footer'

    export default {
        components: {
            NewFooter,
        },
        name: 'Purchaseorder',
        data: function () {
            return {
                loaded: false,
                form: new Form({
                    "id": "",
                    "supplier": "",
                    "address": "",
                    "recipient": "",
                    "ref_number": "",
                    "date": "",
                    "payment_terms": "",
                    "currency": "",
                    "product": "",
                    "document_note": "",
                    "subtotal": "",
                    "discount_rate": "",
                    "discount_amount": "",
                    "vat": "",
                    "total": "",
                    "delivery_date": "",
                    "type": "",
                    "delivery_address": "",
                    "project": "",
                    "delivery_status": "",
                    "billing_status": "",
                    "assigned_to": "",
                    "private_note": "",
                    "attachments": "",
                    "created_at": "",
                    "updated_at": "",
                })
            }
        },
        created: function () {
            this.getPurchaseorder();
        },
        methods: {
            getPurchaseorder: function (Purchaseorder) {

                var that = this;
                this.form.get('/api/purchaseorders/' + this.$route.params.id).then(function (response) {
                    that.form.fill(response.data);
                    that.loaded = true;
                });

            },
            updatePurchaseorder: function () {

                var that = this;
                this.form.put('/api/purchaseorders/' + this.$route.params.id).then(function (response) {
                    that.form.fill(response.data);
                })

            },
            deletePurchaseorder: function () {

                var that = this;
                this.form.delete('/api/purchaseorders/' + this.$route.params.id).then(function (response) {
                    that.form.fill(response.data);
                    that.$router.push('/super-admin/purchaseorders');
                })

            }
        }
    }
</script>
