<template>
    <div class="submenu card content-card">
        <div class="body">
            <!-- Nav tabs -->
            <ul class="nav nav-tabs tab-nav-right text-center">
                <li>
                    <router-link to="/settings/company-settings">Company Settings</router-link>
                </li>
                <li>
                    <router-link to="/settings/profile">Profile</router-link>
                </li>
                <li>
                    <router-link to="/settings/notifications">Notifications</router-link>
                </li>
                <li>
                    <router-link to="/settings/preferences">Preferences</router-link>
                </li>
                <li>
                    <router-link to="/settings/all-role">Role</router-link>
                </li>

            </ul>
            <!-- Tab panes -->
        </div>
    </div>
</template>
