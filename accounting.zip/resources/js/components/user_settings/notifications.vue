<template>
    <div>
        <sub-header></sub-header>
        <!-- submenu -->
        <!-- full table -->
        <section class="content content-menu content_setting">
            <div class="container-fluid">
                <!-- breadcumbs -->

                <div class="block-header">
                    <div class="row" style="justify-content: center;">
                        <div class="col-md-8">
                            <div class="card" style="margin-bottom: 13px; padding-top: 30px;">
                                <div class="body">
                                    <div class="A54VNK-Mc-e">
                                        <div>
                                            <div class="row A54VNK-uc-a">
                                                <div class="col-sm-3 col-xs-12">
                                                    <span class="control-label">Pickup-only customer</span>
                                                </div>
                                                <div class="col-6">
                                                    <div class="btn-group A54VNK-Cc-c switch-button" aria-atomic="true" tabindex="0">
                                                        <a class="btn btn-primary" href="#" aria-pressed="true" role="button">Yes</a>
                                                        <a class="btn active btn-default" href="#" aria-pressed="false" role="button">No</a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-horizontal A54VNK-Ld-a row">
                                                <label class="control-label col-sm-3 col-xs-12"> Notifications </label>
                                                <div class="col-sm-9 col-xs-12">
                                                    <div class="btn-group A54VNK-Cc-c switch-button" aria-atomic="true" tabindex="0">
                                                        <a class="btn active btn-primary" href="#" aria-pressed="true" role="button">On</a>
                                                        <a class="btn btn-default" href="#" aria-pressed="false" role="button">Off</a>
                                                    </div>
                                                    <br>
                                                    <p class="help-block" style="margin-top: 30px;">
                                                        Enable and disable all email notifications for this user account.
                                                        <span class="bold">sohangood12@gmail.com</span>
                                                    </p>
                                                    <div class="alert alert-info">
                                                        <span class="gwt-InlineLabel">OneUp</span> automatically sends you notifications when due dates or expiration dates are approaching. Here you can turn notifications on and off and set when
                                                        you will be reminded.
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="A54VNK-pe-c">
                                                <div class="form-horizontal no-margin-bottom row">
                                                    <label class="control-label col-sm-3 col-xs-12">Opportunity</label>
                                                    <div class="col-sm-9 col-xs-12">
                                                        <div class="d-flex flex-wrap">
                                                            <div class="A54VNK-pe-b A54VNK-pe-d" style="width:22%;">
                                                                <div class="btn-group A54VNK-Cc-c switch-button" aria-atomic="true" tabindex="0">
                                                                    <a class="btn active btn-primary" href="#" aria-pressed="true" role="button">On</a>
                                                                    <a class="btn btn-default" href="#" aria-pressed="false" role="button">Off</a>
                                                                </div>
                                                            </div>
                                                            <span style="display: flex;">
                                                                <div class="A54VNK-pe-b"><span> Send </span></div>
                                                                <div class="A54VNK-pe-b mx-1" style="width: 50px;">
                                                                    <input type="text" style=" height: 28px;" class="form-control text-center" />
                                                                </div>
                                                                <div class="A54VNK-pe-b  mx-1">
                                                                    <div class="select-panel">
                                                                        <select class="form-control">
                                                                            <option value="days">days</option>
                                                                            <option value="weeks">weeks</option>
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                                <div class="A54VNK-pe-b  mx-1">
                                                                    <div class="select-panel">
                                                                        <select class="form-control">
                                                                            <option value="before">before</option>
                                                                            <option value="after">after</option>
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                                <div class="A54VNK-pe-b  mx-1"><span class="">the expiration date.</span></div>
                                                            </span>
                                                        </div>
                                                        <div class="text-danger A54VNK-pe-a" style="display: none;">
                                                            Delay for the notification must be a number between 0 and 999.
                                                        </div>
                                                        <p class="help-block mt-2">Notify me by email when an opportunity is expiring.</p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="A54VNK-pe-c">
                                                <div class="form-horizontal no-margin-bottom row">
                                                    <label class="control-label col-sm-3 col-xs-12">Task</label>
                                                    <div class="col-sm-9 col-xs-12">
                                                        <div  class="d-flex flex-wrap">
                                                            <div class="A54VNK-pe-b A54VNK-pe-d" style="width:22%;">
                                                                <div class="btn-group A54VNK-Cc-c switch-button" aria-atomic="true" tabindex="0">
                                                                    <a class="btn active btn-primary" href="#" aria-pressed="true" role="button">On</a> <a class="btn btn-default" href="#" aria-pressed="false" role="button">Off</a>
                                                                </div>
                                                            </div>
                                                            <span style="display: flex;">
                                                                <div class="A54VNK-pe-b"><span> Send </span></div>
                                                                <div class="A54VNK-pe-b" style="width: 50px;">
                                                                    <input type="text"  style=" height: 28px;" class="form-control text-center" />
                                                                </div>
                                                                <div class="A54VNK-pe-b mx-1">
                                                                    <div class="select-panel">
                                                                        <select class="form-control">
                                                                            <option value="days">days</option>
                                                                            <option value="weeks">weeks</option>
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                                <div class="A54VNK-pe-b mx-1">
                                                                    <div class="select-panel">
                                                                        <select class="form-control">
                                                                            <option value="before">before</option>
                                                                            <option value="after">after</option>
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                                <div class="A54VNK-pe-b mx-1">
                                                                    <span class="">the due date.</span>
                                                                </div>
                                                            </span>
                                                        </div>
                                                        <div class="text-danger A54VNK-pe-a  mx-1" style="display: none;">
                                                            Delay for the notification must be a number between 0 and 999.
                                                        </div>
                                                        <p class="help-block mt-2">Notify me by email when a task is due.</p>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="A54VNK-pe-c">
                                                <div class="form-horizontal no-margin-bottom row">
                                                    <label class="control-label col-sm-3 col-xs-12">Call</label>
                                                    <div class="col-sm-9 col-xs-12">
                                                        <div class="d-flex flex-wrap">
                                                            <div class="A54VNK-pe-b A54VNK-pe-d"  style="width:22%;">
                                                                <div class="btn-group A54VNK-Cc-c switch-button" aria-atomic="true" tabindex="0">
                                                                    <a class="btn active btn-primary" href="#" aria-pressed="true" role="button">On</a>
                                                                    <a class="btn btn-default" href="#" aria-pressed="false" role="button">Off</a>
                                                                </div>
                                                            </div>
                                                            <span style="display: flex;">
                                                                <div class="A54VNK-pe-b"><span> Send </span></div>
                                                                <div class="A54VNK-pe-b mx-1" style="width: 50px;">
                                                                    <input type="text" style=" height: 28px;" class="form-control text-center" />
                                                                </div>
                                                                <div class="A54VNK-pe-b mx-1">
                                                                    <div class="select-panel">
                                                                        <select class="form-control">
                                                                            <option value="days">days</option>
                                                                            <option value="weeks">weeks</option>
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                                <div class="A54VNK-pe-b mx-1">
                                                                    <div class="select-panel">
                                                                        <select class="form-control">
                                                                            <option value="before">before</option>
                                                                            <option value="after">after</option>
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                                <div class="A54VNK-pe-b mx-1"><span class="">the due date.</span></div>
                                                            </span>
                                                        </div>
                                                        <div class="text-danger A54VNK-pe-a" style="display: none;">
                                                            Delay for the notification must be a number between 0 and 999.
                                                        </div>
                                                        <p class="help-block mt-2">Notify me by email when a call is due.</p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="A54VNK-pe-c">
                                                <div class="form-horizontal no-margin-bottom row">
                                                    <label class="control-label col-sm-3 col-xs-12">Customer Invoice Payment</label>
                                                    <div class="col-sm-9 col-xs-12">
                                                        <div class="d-flex flex-wrap">
                                                            <div class="A54VNK-pe-b A54VNK-pe-d" style="width:22%;">
                                                                <div class="btn-group A54VNK-Cc-c switch-button" aria-atomic="true" tabindex="0">
                                                                    <a class="btn active btn-primary" href="#" aria-pressed="true" role="button">On</a> <a class="btn btn-default" href="#" aria-pressed="false" role="button">Off</a>
                                                                </div>
                                                            </div>
                                                            <span style="display: flex;">
                                                                <div class="A54VNK-pe-b"><span> Send </span></div>
                                                                <div class="A54VNK-pe-b" style="width: 50px;">
                                                                    <input style=" height: 28px;" type="text" class="form-control text-center" />
                                                                </div>
                                                                <div class="A54VNK-pe-b mx-1">
                                                                    <div class="select-panel">
                                                                        <select class="form-control">
                                                                            <option value="days">days</option>
                                                                            <option value="weeks">weeks</option>
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                                <div class="A54VNK-pe-b mx-1">
                                                                    <div class="select-panel">
                                                                        <select class="form-control">
                                                                            <option value="before">before</option>
                                                                            <option value="after">after</option>
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                                <div class="A54VNK-pe-b mx-1"><span class="">the due date.</span></div>
                                                            </span>
                                                        </div>
                                                        <div class="text-danger A54VNK-pe-a  mx-1" style="display: none;">
                                                            Delay for the notification must be a number between 0 and 999.
                                                        </div>
                                                        <p class="help-block mt-2">Notify me by email when a customer invoice payment is due.</p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group col-sm-7 col-sm-offset-3 A54VNK-Ld-c">
                                                <button type="button" class="btn btn-primary">Save Notifications Settings</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- full table -->
    </div>

</template>

<script>
    import SubHeader from './sub_header'

    export default {
        components: {
            SubHeader
        },

        name: 'user_settings',

        data: function () {
            return {
                banks: false,
                form: new Form({
                    "id": "",
                    "bank_name": "",
                    "swift_code": "",
                    "phone": "",
                    "mobile": "",
                    "email": "",
                    "website": "",
                    "address": "",
                    "state": "",
                    "city": "",
                    "zip_code": "",
                    "country": "",
                    "created_at": "",
                    "updated_at": "",
                })
            }
        },
        created: function () {

        },
        methods: {}
    }
</script>
