<template>
    <div>
        <div class="card-header">
            <h3>Create Employee</h3>
        </div>

        <div class="card-body">
            <form action="">
                <div class="row">
                    <div class="form-group floating-label mandatory col-md-6 px-2">
                        <input type="text" id="gwt-uid-380" autocomplete="off" class="form-control form-component" />
                        <label for="gwt-uid-380" class="control-label form-question ellipsis">Name</label>
                    </div>
                    <div class="form-group floating-label mandatory col-md-6 px-2">
                        <input type="text" id="gwt-uid-382" autocomplete="off" class="form-control form-component" />
                        <label for="gwt-uid-382" class="control-label form-question ellipsis">Email</label>
                    </div>
                    <div class="form-group floating-label mandatory col-md-6 px-2">
                        <input type="text" id="gwt-uid-383" autocomplete="off" class="form-control form-component" />
                        <label for="gwt-uid-383" class="control-label form-question ellipsis">Phone Number</label>
                    </div>
                    <div class="form-group floating-label mandatory col-md-6 px-2">
                        <input type="text" id="gwt-uid-383" autocomplete="off" class="form-control form-component" />
                        <label for="gwt-uid-383" class="control-label form-question ellipsis">Job Title</label>
                    </div>
                    <div class="form-group floating-label mandatory col-md-6 px-2">
                        <input type="text" id="gwt-uid-383" autocomplete="off" class="form-control form-component" />
                        <label for="gwt-uid-383" class="control-label form-question ellipsis">Date Of Join</label>
                    </div>
                    <div class="form-group floating-label mandatory col-md-6 px-2">
                        <input type="text" id="gwt-uid-383" autocomplete="off" class="form-control form-component" />
                        <label for="gwt-uid-383" class="control-label form-question ellipsis">Date Of Birth</label>
                    </div>
                    <div class="form-group floating-label mandatory col-md-6 px-2">
                        <input type="text" id="gwt-uid-383" autocomplete="off" class="form-control form-component" />
                        <label for="gwt-uid-383" class="control-label form-question ellipsis">Father Name</label>
                    </div>
                    <div class="form-group floating-label mandatory col-md-6 px-2">
                        <input type="text" id="gwt-uid-383" autocomplete="off" class="form-control form-component" />
                        <label for="gwt-uid-383" class="control-label form-question ellipsis">Mother Name</label>
                    </div>
                    <div class="form-group floating-label mandatory col-md-6 px-2">
                        <input type="text" id="gwt-uid-383" autocomplete="off" class="form-control form-component" />
                        <label for="gwt-uid-383" class="control-label form-question ellipsis">Address</label>
                    </div>
                    <div class="form-group floating-label mandatory col-md-6 px-2">
                        <input type="text" id="gwt-uid-383" autocomplete="off" class="form-control form-component" />
                        <label for="gwt-uid-383" class="control-label form-question ellipsis">Nid Number</label>
                    </div>
                    <div class="form-group floating-label mandatory col-md-6 px-2">
                        <input type="text" id="gwt-uid-383" autocomplete="off" class="form-control form-component" />
                        <label for="gwt-uid-383" class="control-label form-question ellipsis">Private Note</label>
                    </div>
                    <!-- <div class="form-group floating-label mandatory col-md-6 px-2">
                        <input type="text" id="gwt-uid-384" autocomplete="off" class="form-control form-component" />
                        <label for="gwt-uid-384" class="control-label form-question ellipsis">Password</label>
                    </div>
                    <div class="form-group floating-label mandatory col-md-6 px-2">
                        <input type="text" id="gwt-uid-385" autocomplete="off" class="form-control form-component" />
                        <label for="gwt-uid-385" class="control-label form-question ellipsis">Confirm Password</label>
                    </div> -->
                    <div class="form-group pl-4">
                        <button class="btn btn-primary done_btn">Submit</button>
                    </div>
                </div>

            </form>
        </div>
    </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
