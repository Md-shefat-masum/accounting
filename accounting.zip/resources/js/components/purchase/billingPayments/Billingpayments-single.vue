<template>
    <!-- form section -->

    <form action="">
        <div class="right-content form1">
            <div id="contentRootPanel" class="fullpage">
                <div class="A54VNK-ce-a">
                    <div class="page-panel panel-default page-right-content">
                        <div>
                            <div class="panel-body page-panel-body">
                                <div>
                                    <div>
                                        <div>
                                            <div class="row">
                                                <div class="col-sm-6">
                                                    <div>
                                                        <div>
                                                            <div class="form-horizontal">
                                                                <div class="form-group row">
                                                                    <div class="col-sm-4 col-4 control-label">
                                                                        <label class="" style="font-weight: normal;">Bank</label>
                                                                        <span class="text-danger bold">*</span>
                                                                    </div>
                                                                    <div class="col-sm-8 col-8">
                                                                        <div class="A54VNK-ni-a">
                                                                            <div class="select-panel A54VNK-ni-c">
                                                                                <select class="form-control" size="1">
                                                                                    <option value="0">Select a Bank Account</option>
                                                                                </select>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <hr>
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div>
                                        <div>
                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <div>
                                                        <div>
                                                            <div>
                                                                <table class="A54VNK-Ff-y table table-hover table-link A54VNK-Ff-z empty" cellspacing="0" style="table-layout: fixed;">
                                                                    <colgroup>
                                                                        <col style="width: 30%;">
                                                                        <col style="width: 30%;">
                                                                        <col style="width: 30%;">
                                                                        <col style="width: 30%;">
                                                                        <col style="width: 30%;">
                                                                        <col style="width: 30%;">
                                                                        <col style="width: 30%;">
                                                                    </colgroup>
                                                                    <thead>
                                                                        <tr>
                                                                            <th colspan="1" class="A54VNK-Ff-h">
                                                                                <div>
                                                                                    <span class="ellipsis ellipsis-block header-small" data-title="Select" data-toggle="tooltip">Select</span>
                                                                                    <span class="header-normal">Select</span>
                                                                                </div>
                                                                            </th>
                                                                            <th colspan="1" class="A54VNK-Ff-h">
                                                                                <div>
                                                                                    <span class="ellipsis ellipsis-block header-small" data-title="Date" data-toggle="tooltip">Date</span>
                                                                                    <span class="header-normal">Date</span>
                                                                                </div>
                                                                            </th>
                                                                            <th colspan="1" class="A54VNK-Ff-h">
                                                                                <div>
                                                                                    <span class="ellipsis ellipsis-block header-small" data-title="Supplier" data-toggle="tooltip">Supplier </span>
                                                                                    <span class="header-normal">Supplier </span>
                                                                                </div>
                                                                            </th>
                                                                            <th colspan="1" class="A54VNK-Ff-h">
                                                                                <div>
                                                                                    <span class="ellipsis ellipsis-block header-small" data-title="#Bill" data-toggle="tooltip">#Bill</span>
                                                                                    <span class="header-normal">#Bill</span>
                                                                                </div>
                                                                            </th>
                                                                            <th colspan="1" class="A54VNK-Ff-h">
                                                                                <div>
                                                                                    <span class="ellipsis ellipsis-block header-small" data-title="Pay" data-toggle="tooltip">Pay</span>
                                                                                    <span class="header-normal">Pay</span>
                                                                                </div>
                                                                            </th>
                                                                            <th colspan="1" class="A54VNK-Ff-h A54VNK-Ff-p">
                                                                                <div>
                                                                                    <span class="ellipsis ellipsis-block header-small" data-title="Type" data-toggle="tooltip">Type</span>
                                                                                    <span class="header-normal">Type</span>
                                                                                </div>
                                                                            </th>
                                                                            <th colspan="1" class="A54VNK-Ff-h A54VNK-Ff-p">
                                                                                <div>
                                                                                    <span class="ellipsis ellipsis-block header-small" data-title="#" data-toggle="tooltip">#</span>
                                                                                    <span class="header-normal">#</span>
                                                                                </div>
                                                                            </th>
                                                                        </tr>
                                                                    </thead>
                                                                    <tbody>
                                                                        <tr class="A54VNK-Ff-r">
                                                                            <td class="A54VNK-Ff-a A54VNK-Ff-s A54VNK-Ff-d">
                                                                                <div style="outline-style:none;">Select</div>
                                                                            </td>
                                                                            <td class="A54VNK-Ff-a A54VNK-Ff-s">
                                                                                <div style="outline-style:none;">Date</div>
                                                                            </td>
                                                                            <td class="A54VNK-Ff-a A54VNK-Ff-s">
                                                                                <div style="outline-style:none;">
                                                                                    Supplier
                                                                                </div>
                                                                            </td>
                                                                            <td class="A54VNK-Ff-a A54VNK-Ff-s">
                                                                                <div style="outline-style:none;">
                                                                                    #Bill
                                                                                </div>
                                                                            </td>
                                                                            <td class="A54VNK-Ff-a A54VNK-Ff-s">
                                                                                <div style="outline-style:none;">
                                                                                    Pay
                                                                                </div>
                                                                            </td>
                                                                            <td class="A54VNK-Ff-a A54VNK-Ff-s">
                                                                                <div style="outline-style:none;">
                                                                                    Type
                                                                                </div>
                                                                            </td>
                                                                            <td class="A54VNK-Ff-a A54VNK-Ff-s A54VNK-Ff-A">
                                                                                <div style="outline-style:none;">#</div>
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                    <tbody>
                                                                        <tr>
                                                                            <td align="center" colspan="7">
                                                                                <div>
                                                                                    <div style="width: 100%; height: 100%; padding: 0px; margin: 0px;">
                                                                                        <div style="width: 100%; height: 100%;">
                                                                                            <div class="text-muted text-left">No items to show</div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div aria-hidden="true" style="width: 100%; height: 100%; padding: 0px; margin: 0px; display: none;">
                                                                                        <div aria-hidden="true" class="A54VNK-Ff-q" style="width: 100%; height: 100%; display: none;">
                                                                                            <div class="text-muted text-left">Loading data...</div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div>
                                        <div>
                                            <a class="accordion-toggle collapsed A54VNK-ri-a" data-toggle="collapse" href="#gwt-uid-637">Advanced</a>
                                            <div class="panel-collapse collapse" id="gwt-uid-637">
                                                <div class="panel-body">
                                                    <div>
                                                        <div>
                                                            <div class="row">
                                                                <div class="col-sm-12">
                                                                    <div>
                                                                        <div>
                                                                            <div class="form-horizontal">
                                                                                <div class="form-group row"style="margin-bottom: 15px !important;">
                                                                                    <div class="col-sm-4 col-4 control-label">
                                                                                        <label class="" style="font-weight: normal;">Payment Date</label>
                                                                                    </div>
                                                                                    <div class="col-sm-8 col-8">
                                                                                        <input type="text" class="form-control">
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <hr>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <new-footer type="basic"/>
                </div>
            </div>
        </div>
    </form>

    <!-- form section -->
</template>

<script>
    import NewFooter from '../../../layouts/partials/new_footer'

    export default {
        components: {
            NewFooter,
        },
        name: 'Billingpayment',
        data: function () {
            return {
                loaded: false,
                form: new Form({
                    "id": "",
                    "bank": "",
                    "currency": "",
                    "date": "",
                    "supplier": "",
                    "bill": "",
                    "pay": "",
                    "type": "",
                    "payment_date": "",
                    "created_at": "",
                    "updated_at": "",
                })
            }
        },
        created: function () {
            this.getBillingpayment();
        },
        methods: {
            getBillingpayment: function (Billingpayment) {

                var that = this;
                this.form.get('/api/billingpayments/' + this.$route.params.id).then(function (response) {
                    that.form.fill(response.data);
                    that.loaded = true;
                });

            },
            updateBillingpayment: function () {

                var that = this;
                this.form.put('/api/billingpayments/' + this.$route.params.id).then(function (response) {
                    that.form.fill(response.data);
                })

            },
            deleteBillingpayment: function () {

                var that = this;
                this.form.delete('/api/billingpayments/' + this.$route.params.id).then(function (response) {
                    that.form.fill(response.data);
                    that.$router.push('/super-admin/billingpayments');
                })

            }
        }
    }
</script>
