<template>
    <!-- form section -->

    <form action="">
        <div class="right-content form1">
            <div id="contentRootPanel" class="fullpage">
                <div class="A54VNK-ce-a">
                    <div class="page-panel panel-default page-right-content">
                        <div>
                            <div class="panel-body page-panel-body">
                                <div>
                                    <div>
                                        <div>
                                            <div class="row">
                                                <div class="col-sm-6">
                                                    <div>
                                                        <div>
                                                            <div class="form-horizontal">
                                                                <div class="form-group row">
                                                                    <div class="col-sm-4 col-4 control-label">
                                                                        <label class="" style="font-weight: normal;">Supplier</label>
                                                                        <span class="text-danger bold">*</span>
                                                                    </div>
                                                                    <div class="col-sm-8 col-8">
                                                                        <div class="dropdown">
                                                                            <a class="A54VNK-pi-a" style="">
                                                                                <span class="picto-font">D</span>
                                                                            </a>
                                                                            <input type="text" class="form-control A54VNK-pi-d" data-toggle="dropdown" autocomplete="off" role="button" placeholder="Supplier name or code" aria-expanded="true">
                                                                            <ul class="dropdown-menu A54VNK-pi-c">
                                                                                <li class="active">
                                                                                    <a class="ellipsis-block" role="button">supplier.company_name</a>
                                                                                    <a class="ellipsis-block" role="button">supplier.first_name supplier.last_name</a>
                                                                                </li>
                                                                                <li class="active">
                                                                                    <a class="ellipsis-block" role="button">View all Leads and Supplier</a>
                                                                                </li>
                                                                                <li class="">
                                                                                    <a class="ellipsis-block" role="button">Create a Lead or Supplier</a>
                                                                                </li>
                                                                            </ul>
                                                                        </div>
                                                                        <div class="error-panel"></div>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group row">
                                                                    <div class="col-sm-4 col-4 control-label">
                                                                        <label class="" style="font-weight: normal;">Address</label>
                                                                    </div>
                                                                    <div class="col-sm-8 col-8">
                                                                        <textarea class="form-control" rows="4" disabled="" style="resize: vertical; min-height: 50px;"></textarea>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group row">
                                                                    <div class="col-sm-4 col-4 control-label">
                                                                        <label class="" style="font-weight: normal;">Recipient</label>
                                                                    </div>
                                                                    <div class="col-sm-8 col-8">
                                                                        <div class="A54VNK-ni-a">
                                                                            <div class="select-panel A54VNK-ni-c">
                                                                                <select class="form-control" size="1">
                                                                                    <option value="0">none</option>
                                                                                    <option>contact.contacts.first_name contact.contacts.last_name</option>
                                                                                </select>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <hr>
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div>
                                                        <div>
                                                            <div class="form-horizontal">
                                                                <div class="form-group row">
                                                                    <div class="col-sm-4 col-4 control-label">
                                                                        <label class="" style="font-weight: normal;">Ref. Number</label>
                                                                    </div>
                                                                    <div class="col-sm-8 col-8">
                                                                        <input type="text" class="form-control A54VNK-oi-b">
                                                                    </div>
                                                                </div>
                                                                <div class="form-group row">
                                                                    <div class="col-sm-4 col-4 control-label">
                                                                        <label class="" style="font-weight: normal;">Date</label>
                                                                    </div>
                                                                    <div class="col-sm-8 col-8">
                                                                        <div class="input-group">
                                                                            <input type="text" class="form-control">
                                                                        </div>
                                                                        <div class="error-panel"></div>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group row">
                                                                    <div class="col-sm-4 col-4 control-label">
                                                                        <label class="" style="font-weight: normal;">Payment Terms</label>
                                                                    </div>
                                                                    <div class="col-sm-8 col-8">
                                                                        <div class="dropdown">
                                                                            <input type="text" class="form-control A54VNK-oi-b" data-toggle="dropdown" autocomplete="off" role="button" placeholder="Search results">
                                                                            <ul class="dropdown-menu A54VNK-oi-a">
                                                                                <li class="active">
                                                                                    <a class="ellipsis-block" role="button" title="Due on receipt">
                                                                                        <strong>Due</strong> <strong>on</strong> <strong>receipt</strong>
                                                                                    </a>
                                                                                </li>
                                                                                <li class="divider"></li>
                                                                                <li class=""><a class="ellipsis-block" role="button">Start the search</a></li>
                                                                                <li class=""><a class="ellipsis-block" role="button">Create a new...</a></li>
                                                                            </ul>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <hr>
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div>
                                                        <div>
                                                            <div class="form-horizontal">
                                                                <div class="form-group row">
                                                                    <div class="col-sm-12 col-xs-12">
                                                                        <div class="btn-group A54VNK-uc-c switch-button btn-group-justified" aria-atomic="true" tabindex="0">
                                                                            <a class="btn btn-default" href="#" aria-pressed="false" role="button" style="width: 50%;">Unpaid</a>
                                                                            <a class="btn active btn-primary" href="#" aria-pressed="true" role="button" style="width: 50%;">Settled</a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div>
                                                        <div>
                                                            <div class="form-horizontal">
                                                                <div class="form-group row">
                                                                    <div class="col-sm-4 col-4 control-label">
                                                                        <label class="" style="font-weight: normal;">Bank</label>
                                                                        <span class="text-danger bold">*</span>
                                                                    </div>
                                                                    <div class="col-sm-8 col-8">
                                                                        <div class="A54VNK-ni-a">
                                                                            <div class="select-panel A54VNK-ni-c">
                                                                                <select class="form-control" size="1">
                                                                                    <option value="0">Select a Bank Account</option>
                                                                                </select>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <hr>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div>
                                        <div>
                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                                                        <li class="nav-item">
                                                            <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">Product and Services</a>
                                                        </li>
                                                        <li class="nav-item">
                                                            <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">Expenses</a>
                                                        </li>
                                                    </ul>
                                                </div>
                                                <div class="col-sm-12">
                                                    <div>
                                                        <div>
                                                            <div>
                                                                <table class="A54VNK-Ff-y table table-hover table-link A54VNK-Ff-z empty" cellspacing="0" style="table-layout: fixed;">
                                                                    <colgroup>
                                                                        <col style="width: 15%;">
                                                                        <col style="width: 25%;">
                                                                        <col style="width: 70%;">
                                                                        <col style="width: 20%;">
                                                                        <col style="width: 25%;">
                                                                        <col style="width: 20%;">
                                                                        <col style="width: 30%;">
                                                                        <col style="width: 25%;">
                                                                    </colgroup>
                                                                    <thead>
                                                                        <tr>
                                                                            <th colspan="1" class="A54VNK-Ff-h A54VNK-Ff-f">
                                                                                <div>
                                                                                    <span class="ellipsis ellipsis-block header-small" data-title="" data-toggle="tooltip"></span>
                                                                                    <span class="header-normal"></span>
                                                                                </div>
                                                                            </th>
                                                                            <th colspan="1" class="A54VNK-Ff-h">
                                                                                <div>
                                                                                    <span class="ellipsis ellipsis-block header-small" data-title="" data-toggle="tooltip"></span>
                                                                                    <span class="header-normal"></span>
                                                                                </div>
                                                                            </th>
                                                                            <th colspan="1" class="A54VNK-Ff-h">
                                                                                <div>
                                                                                    <span class="ellipsis ellipsis-block header-small" data-title="Description" data-toggle="tooltip">Description</span>
                                                                                    <span class="header-normal">Description</span>
                                                                                </div>
                                                                            </th>
                                                                            <th colspan="1" class="A54VNK-Ff-h">
                                                                                <div>
                                                                                    <span class="ellipsis ellipsis-block header-small" data-title="Qty" data-toggle="tooltip">Qty</span>
                                                                                    <span class="header-normal">Qty</span>
                                                                                </div>
                                                                            </th>
                                                                            <th colspan="1" class="A54VNK-Ff-h">
                                                                                <div>
                                                                                    <span class="ellipsis ellipsis-block header-small" data-title="Price	" data-toggle="tooltip">Price </span>
                                                                                    <span class="header-normal">Price </span>
                                                                                </div>
                                                                            </th>
                                                                            <th colspan="1" class="A54VNK-Ff-h">
                                                                                <div>
                                                                                    <span class="ellipsis ellipsis-block header-small" data-title="Disc.%" data-toggle="tooltip">Disc.%</span>
                                                                                    <span class="header-normal">Disc.%</span>
                                                                                </div>
                                                                            </th>
                                                                            <th colspan="1" class="A54VNK-Ff-h">
                                                                                <div>
                                                                                    <span class="ellipsis ellipsis-block header-small" data-title="Total" data-toggle="tooltip">Total</span>
                                                                                    <span class="header-normal">Total</span>
                                                                                </div>
                                                                            </th>
                                                                            <th colspan="1" class="A54VNK-Ff-h A54VNK-Ff-p">
                                                                                <div>
                                                                                    <span class="ellipsis ellipsis-block header-small" data-title="VAT%" data-toggle="tooltip">VAT%</span>
                                                                                    <span class="header-normal">VAT%</span>
                                                                                </div>
                                                                            </th>
                                                                        </tr>
                                                                    </thead>
                                                                    <tbody>
                                                                        <tr class="A54VNK-Ff-r">
                                                                            <td class="A54VNK-Ff-a A54VNK-Ff-s A54VNK-Ff-d">
                                                                                <div style="outline-style:none;">321</div>
                                                                            </td>
                                                                            <td class="A54VNK-Ff-a A54VNK-Ff-s">
                                                                                <div style="outline-style:none;">321</div>
                                                                            </td>
                                                                            <td class="A54VNK-Ff-a A54VNK-Ff-s">
                                                                                <div style="outline-style:none;">
                                                                                    <textarea class="form-control" rows="1"></textarea>
                                                                                </div>
                                                                            </td>
                                                                            <td class="A54VNK-Ff-a A54VNK-Ff-s">
                                                                                <div style="outline-style:none;">
                                                                                    <input type="text" value="1.00" class="form-control">
                                                                                </div>
                                                                            </td>
                                                                            <td class="A54VNK-Ff-a A54VNK-Ff-s">
                                                                                <div style="outline-style:none;">
                                                                                    <input type="text" value="0.00" class="form-control">
                                                                                </div>
                                                                            </td>
                                                                            <td class="A54VNK-Ff-a A54VNK-Ff-s">
                                                                                <div style="outline-style:none;">
                                                                                    <input type="text" value="0.00" class="form-control">
                                                                                </div>
                                                                            </td>
                                                                            <td class="A54VNK-Ff-a A54VNK-Ff-s A54VNK-Ff-A">
                                                                                <div style="outline-style:none;">321</div>
                                                                            </td>
                                                                            <td class="A54VNK-Ff-a A54VNK-Ff-s A54VNK-Ff-n">
                                                                                <div style="outline-style:none;">
                                                                                    <div class="dropdown">
                                                                                        <input type="text" class="form-control A54VNK-Yj-b" placeholder="Search results" data-toggle="dropdown" autocomplete="off">
                                                                                        <ul class="dropdown-menu A54VNK-Yj-a">
                                                                                            <li class="">
                                                                                                <a class="ellipsis-block" role="button">0.0% Vat</a>
                                                                                            </li>
                                                                                            <li class="">
                                                                                                <a class="ellipsis-block" role="button" >tax.tax_rate% tax.tax_name</a>
                                                                                            </li>
                                                                                        </ul>
                                                                                    </div>
                                                                                </div>
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                    <tbody>
                                                                        <tr>
                                                                            <td align="center" colspan="8">
                                                                                <div>
                                                                                    <div style="width: 100%; height: 100%; padding: 0px; margin: 0px;">
                                                                                        <div style="width: 100%; height: 100%;">
                                                                                            <div class="text-muted text-left">No items to show</div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div aria-hidden="true" style="width: 100%; height: 100%; padding: 0px; margin: 0px; display: none;">
                                                                                        <div aria-hidden="true" class="A54VNK-Ff-q" style="width: 100%; height: 100%; display: none;">
                                                                                            <div class="text-muted text-left">Loading data...</div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                                <table class="A54VNK-Ff-y table table-hover table-link A54VNK-Ff-z empty" cellspacing="0" style="table-layout: fixed;">
                                                                    <colgroup>
                                                                        <col style="width: 80%;">
                                                                        <col style="width: 25%;">
                                                                        <col style="width: 25%;">
                                                                        <col style="width: 25%;">
                                                                        <col style="width: 30%;">
                                                                    </colgroup>
                                                                    <thead>
                                                                        <tr>
                                                                            <th colspan="1" class="A54VNK-Ff-h">
                                                                                <div>
                                                                                    <span class="ellipsis ellipsis-block header-small" data-title="Accounting Account" data-toggle="tooltip">Accounting Account</span>
                                                                                    <span class="header-normal">Accounting Account</span>
                                                                                </div>
                                                                            </th>
                                                                            <th colspan="1" class="A54VNK-Ff-h">
                                                                                <div>
                                                                                    <span class="ellipsis ellipsis-block header-small" data-title="Amount" data-toggle="tooltip">Amount</span>
                                                                                    <span class="header-normal">Amount</span>
                                                                                </div>
                                                                            </th>
                                                                            <th colspan="1" class="A54VNK-Ff-h">
                                                                                <div>
                                                                                    <span class="ellipsis ellipsis-block header-small" data-title="Disc.%" data-toggle="tooltip">Disc.%</span>
                                                                                    <span class="header-normal">Disc.%</span>
                                                                                </div>
                                                                            </th>
                                                                            <th colspan="1" class="A54VNK-Ff-h A54VNK-Ff-p">
                                                                                <div>
                                                                                    <span class="ellipsis ellipsis-block header-small" data-title="VAT%" data-toggle="tooltip">VAT%</span>
                                                                                    <span class="header-normal">VAT%</span>
                                                                                </div>
                                                                            </th>
                                                                            <th colspan="1" class="A54VNK-Ff-h">
                                                                                <div>
                                                                                    <span class="ellipsis ellipsis-block header-small" data-title="Total" data-toggle="tooltip">Total</span>
                                                                                    <span class="header-normal">Total</span>
                                                                                </div>
                                                                            </th>
                                                                        </tr>
                                                                    </thead>
                                                                    <tbody>
                                                                        <tr class="A54VNK-Ff-r">
                                                                            <td class="A54VNK-Ff-a A54VNK-Ff-s">
                                                                                <div style="outline-style:none;">
                                                                                    <div class="dropdown" style="width: 100%;">
                                                                                        <input type="text" class="form-control A54VNK-Yj-b" placeholder="Search results" data-toggle="dropdown" autocomplete="off">
                                                                                        <ul class="dropdown-menu A54VNK-Yj-a">
                                                                                            <li class="">
                                                                                                <a class="ellipsis-block" role="button">0.0% Vat</a>
                                                                                            </li>
                                                                                            <li class="">
                                                                                                <a class="ellipsis-block" role="button" >tax.tax_rate% tax.tax_name</a>
                                                                                            </li>
                                                                                        </ul>
                                                                                    </div>
                                                                                </div>
                                                                            </td>
                                                                            <td class="A54VNK-Ff-a A54VNK-Ff-s">
                                                                                <div style="outline-style:none;">
                                                                                    <input type="text" value="0.00" class="form-control">
                                                                                </div>
                                                                            </td>
                                                                            <td class="A54VNK-Ff-a A54VNK-Ff-s">
                                                                                <div style="outline-style:none;">
                                                                                    <input type="text" value="0.00" class="form-control">
                                                                                </div>
                                                                            </td>
                                                                            <td class="A54VNK-Ff-a A54VNK-Ff-s A54VNK-Ff-n">
                                                                                <div style="outline-style:none;">
                                                                                    <div class="dropdown">
                                                                                        <input type="text" class="form-control A54VNK-Yj-b" placeholder="Search results" data-toggle="dropdown" autocomplete="off">
                                                                                        <ul class="dropdown-menu A54VNK-Yj-a">
                                                                                            <li class="">
                                                                                                <a class="ellipsis-block" role="button">0.0% Vat</a>
                                                                                            </li>
                                                                                            <li class="">
                                                                                                <a class="ellipsis-block" role="button" >tax.tax_rate% tax.tax_name</a>
                                                                                            </li>
                                                                                        </ul>
                                                                                    </div>
                                                                                </div>
                                                                            </td>
                                                                            <td class="A54VNK-Ff-a A54VNK-Ff-s A54VNK-Ff-A">
                                                                                <div style="outline-style:none;">321</div>
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                    <tbody>
                                                                        <tr>
                                                                            <td align="center" colspan="5">
                                                                                <div>
                                                                                    <div style="width: 100%; height: 100%; padding: 0px; margin: 0px;">
                                                                                        <div style="width: 100%; height: 100%;">
                                                                                            <div class="text-muted text-left">No items to show</div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div aria-hidden="true" style="width: 100%; height: 100%; padding: 0px; margin: 0px; display: none;">
                                                                                        <div aria-hidden="true" class="A54VNK-Ff-q" style="width: 100%; height: 100%; display: none;">
                                                                                            <div class="text-muted text-left">Loading data...</div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                        </div>
                                                        <div class="btn-toolbar A54VNK-Ki-a">
                                                            <button type="button" class="btn btn-default mt-2">
                                                                <span class="picto-font">s</span> Add Product or Service
                                                            </button>
                                                            <button type="button" class="btn btn-default ml-2 mt-2">
                                                                <span class="picto-font">-</span> Delete
                                                            </button>
                                                            <button type="button" class="btn btn-default ml-2 mt-2" disabled>
                                                                <span class="picto-font"></span>
                                                            </button>
                                                            <button type="button" class="btn btn-default ml-2 mt-2">
                                                                <span class="picto-font"></span>
                                                            </button>
                                                            <button type="button" class="btn btn-default ml-2 mt-2" disabled>
                                                                <span class="picto-font"></span>
                                                            </button>
                                                            <button type="button" class="btn btn-default ml-2 mt-2">
                                                                <span class="picto-font"></span>
                                                            </button>
                                                        </div>
                                                        <div class="btn-toolbar A54VNK-Ki-a">
                                                            <button type="button" class="btn btn-default mt-2">
                                                                <span class="picto-font">s</span> Add Expenses
                                                            </button>
                                                            <button type="button" class="btn btn-default ml-2 mt-2">
                                                                <span class="picto-font">-</span> Delete
                                                            </button>
                                                            <button type="button" class="btn btn-default ml-2 mt-2" disabled>
                                                                <span class="picto-font"></span>
                                                            </button>
                                                            <button type="button" class="btn btn-default ml-2 mt-2">
                                                                <span class="picto-font"></span>
                                                            </button>
                                                            <button type="button" class="btn btn-default ml-2 mt-2" disabled>
                                                                <span class="picto-font"></span>
                                                            </button>
                                                            <button type="button" class="btn btn-default ml-2 mt-2">
                                                                <span class="picto-font"></span>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div>
                                        <div>
                                            <div class="row">
                                                <div class="col-sm-6">
                                                    <div >
                                                        <div>
                                                            <div class="form-horizontal">
                                                                <div class="form-group row" style="margin-bottom: 15px !important;">
                                                                    <div class="col-sm-4 col-4 control-label">
                                                                        <label class="" style="font-weight: normal;">Document Note</label>
                                                                    </div>
                                                                    <div class="col-sm-8 col-8">
                                                                        <textarea class="form-control" rows="3" style="resize: vertical; min-height: 50px;"></textarea>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <hr>
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div>
                                                        <div>
                                                            <div class="row">
                                                                <div class="col-sm-12">
                                                                    <div >
                                                                        <div>
                                                                            <div class="form-horizontal">
                                                                                <div class="form-group row" style="margin-bottom: 15px !important;">
                                                                                    <div class="col-sm-4 col-4 control-label">
                                                                                        <label class="" style="font-weight: normal;">Subtotal</label>
                                                                                    </div>
                                                                                    <div class="col-sm-8 col-8">
                                                                                        <input type="text" class="form-control" disabled="" style="text-align: right;" >
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <hr>
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-12">
                                                                    <div>
                                                                        <div>
                                                                            <div class="form-horizontal">
                                                                                <div class="form-group row" style="margin-bottom: 15px !important;">
                                                                                    <div class="col-sm-4 col-4 control-label">
                                                                                        <label class="" style="font-weight: normal;">Discount Rate</label>
                                                                                    </div>
                                                                                    <div class="col-sm-8 col-8">
                                                                                        <input type="text" class="form-control" style="text-align: right;">
                                                                                    </div>
                                                                                </div>
                                                                                <div class="form-group row" style="margin-bottom: 15px !important;">
                                                                                    <div class="col-sm-4 col-4 control-label">
                                                                                        <label class="" style="font-weight: normal;">Discount Amount</label>
                                                                                    </div>
                                                                                    <div class="col-sm-8 col-8">
                                                                                        <input type="text" class="form-control" disabled="" style="text-align: right;">
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <hr>
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-12">
                                                                    <div>
                                                                        <div>
                                                                            <div class="form-horizontal">
                                                                                <div class="form-group row" style="margin-bottom: 15px !important;">
                                                                                    <div class="col-sm-4 col-4 control-label">
                                                                                        <label class="" style="font-weight: normal;">VAT</label>
                                                                                    </div>
                                                                                    <div class="col-sm-8 col-8">
                                                                                        <input type="text" class="form-control" disabled="" style="text-align: right;">
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <hr>
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-12">
                                                                    <div>
                                                                        <div>
                                                                            <div class="form-horizontal">
                                                                                <div class="form-group row" style="margin-bottom: 15px !important;">
                                                                                    <div class="col-sm-4 col-4 control-label">
                                                                                        <label class="" style="font-weight: normal;">Total</label>
                                                                                    </div>
                                                                                    <div class="col-sm-8 col-8">
                                                                                        <input type="text" class="form-control" disabled="" style="text-align: right;">
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <hr>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div>
                                        <div>
                                            <a class="accordion-toggle collapsed A54VNK-ri-a" data-toggle="collapse" href="#gwt-uid-637">Advanced</a>
                                            <div class="panel-collapse collapse" id="gwt-uid-637">
                                                <div class="panel-body">
                                                    <div>
                                                        <div>
                                                            <div class="row">
                                                                <div class="col-sm-12">
                                                                    <div >
                                                                        <div>
                                                                            <div class="form-horizontal">
                                                                                <div class="form-group row"style="margin-bottom: 15px !important;">
                                                                                    <div class="col-sm-4 col-4 control-label">
                                                                                        <label class="" style="font-weight: normal;">Delivery Date</label>
                                                                                    </div>
                                                                                    <div class="col-sm-8 col-8">
                                                                                        <input type="text" class="form-control">
                                                                                    </div>
                                                                                </div>
                                                                                <div class="form-group row"style="margin-bottom: 15px !important;">
                                                                                    <div class="col-sm-4 col-4 control-label">
                                                                                        <label class="" style="font-weight: normal;">Type</label>
                                                                                    </div>
                                                                                    <div class="col-sm-8 col-8">
                                                                                        <div class="A54VNK-ni-a">
                                                                                            <div class="select-panel A54VNK-ni-c">
                                                                                                <select class="form-control" size="1">
                                                                                                    <option value="0">none</option>
                                                                                                    <option>contact.contacts.first_name contact.contacts.last_name</option>
                                                                                                </select>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="form-group row"style="margin-bottom: 15px !important;">
                                                                                    <div class="col-sm-4 col-4 control-label">
                                                                                        <label class="" style="font-weight: normal;">Delivery Address</label>
                                                                                    </div>
                                                                                    <div class="col-sm-8 col-8">
                                                                                        <textarea class="form-control" rows="4" disabled="" style="resize: vertical; min-height: 50px;"></textarea>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <hr>
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-12">
                                                                    <div>
                                                                        <div>
                                                                            <div class="form-horizontal">
                                                                                <div class="form-group row"style="margin-bottom: 15px !important;">
                                                                                    <div class="col-sm-4 col-4 control-label">
                                                                                        <label class="" style="font-weight: normal;">Project</label>
                                                                                    </div>
                                                                                    <div class="col-sm-8 col-8">
                                                                                        <div class="dropdown">
                                                                                            <a class="A54VNK-pi-a" style="">
                                                                                                <span class="picto-font">D</span>
                                                                                            </a>
                                                                                            <input type="text" class="form-control A54VNK-pi-d" data-toggle="dropdown" autocomplete="off" role="button" placeholder="Project name">
                                                                                            <ul class="dropdown-menu A54VNK-pi-c">
                                                                                                <li class="disabled"><a> No result </a></li>
                                                                                                <li class="divider"></li>
                                                                                            </ul>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="form-group row"style="margin-bottom: 15px !important;" >
                                                                                    <div class="col-sm-4 col-4 control-label">
                                                                                        <label class="" style="font-weight: normal;">Delivery Status</label>
                                                                                    </div>
                                                                                    <div class="col-sm-8 col-8">
                                                                                        <div class="A54VNK-ni-a">
                                                                                            <div class="select-panel A54VNK-ni-c">
                                                                                                <select class="form-control" size="1">
                                                                                                    <option value="0">none</option>
                                                                                                    <option>contact.contacts.first_name contact.contacts.last_name</option>
                                                                                                </select>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="form-group row"style="margin-bottom: 15px !important;">
                                                                                    <div class="col-sm-4 col-4 control-label">
                                                                                        <label class="" style="font-weight: normal;">Billing Status</label>
                                                                                    </div>
                                                                                    <div class="col-sm-8 col-8">
                                                                                        <div class="A54VNK-ni-a">
                                                                                            <div class="select-panel A54VNK-ni-c">
                                                                                                <select class="form-control" size="1">
                                                                                                    <option value="0">none</option>
                                                                                                    <option>contact.contacts.first_name contact.contacts.last_name</option>
                                                                                                </select>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <hr>
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-12">
                                                                    <div>
                                                                        <div>
                                                                            <div class="form-horizontal">
                                                                                <div class="form-group row"style="margin-bottom: 15px !important;">
                                                                                    <div class="col-sm-4 col-4 control-label">
                                                                                        <label class="" style="font-weight: normal;">Private Note</label>
                                                                                    </div>
                                                                                    <div class="col-sm-8 col-8">
                                                                                        <textarea class="form-control" rows="3" style="resize: vertical; min-height: 50px;"></textarea>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <hr>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-12 A54VNK-qi-c">
                                            <label><b>Attachments</b></label>
                                        </div>
                                        <div class="container-fluid">
                                            <div class="row A54VNK-qi-a" id="dvPreview">
                                                <div class="col-12 col-sm-4 col-md-3 A54VNK-kh-b">
                                                    <div class="A54VNK-kh-a">
                                                        <div class="A54VNK-kh-g">
                                                            <img class="img-responsive">
                                                        </div>
                                                        <div class="A54VNK-kh-e">
                                                            <div class="ellipsis-block A54VNK-kh-f bolder">image.name</div>
                                                            <div class="small text-muted">Added on imagedate</div>
                                                        </div>
                                                    </div>
                                                    <button type="button" class="A54VNK-kh-c" title="Delete">×</button>
                                                </div>
                                            </div>
                                            <div class="A54VNK-Ri-b">
                                                <div class="A54VNK-Ri-e">
                                                    <div class="picto-font A54VNK-Ri-d drap_mob_none"></div>
                                                    <div class="drap_mob_none"> Drag files to attach , or </div> <label for="upload-photo" class="btn btn-link A54VNK-Ri-a" style="margin-bottom: 0;padding-top: 6px;padding-left: 0;padding-bottom: 0;text-transform: capitalize;">Browse files from your device</label>
                                                </div>
                                                <div class="text-muted A54VNK-Ri-c"> or </div>
                                                <label class="btn btn-default" for="upload-photo" style="margin-bottom: 0;text-transform: capitalize;font-weight: 400;">Browse uploaded files</label>
                                                <input type="file" name="photo" id="upload-photo"  multiple="multiple" style="opacity: 0;position: absolute;z-index: -1;">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <new-footer type="basic"/>
                </div>
            </div>
        </div>
    </form>

    <!-- form section -->

</template>

<script>
    import NewFooter from '../../../layouts/partials/new_footer'

    export default {
        components: {
            NewFooter,
        },
        name: 'Bill',
        data: function () {
            return {
                loaded: false,
                form: new Form({
                    "id": "",
                    "supplier": "",
                    "ref_number": "",
                    "address": "",
                    "recipient": "",
                    "date": "",
                    "payment_terms": "",
                    "currency": "",
                    "is_unpaid": "",
                    "is_settled": "",
                    "bank": "",
                    "products": "",
                    "expenses": "",
                    "document_note": "",
                    "subtotal": "",
                    "discount_rate": "",
                    "discount_amount": "",
                    "vat": "",
                    "total": "",
                    "delivery_date": "",
                    "type": "",
                    "delivery_address": "",
                    "project": "",
                    "delivery_status": "",
                    "billing_status": "",
                    "assigned_to": "",
                    "private_note": "",
                    "attachments": "",
                    "created_at": "",
                    "updated_at": "",
                })
            }
        },
        created: function () {
            this.getBill();
        },
        methods: {
            getBill: function (Bill) {

                var that = this;
                this.form.get('/api/bills/' + this.$route.params.id).then(function (response) {
                    that.form.fill(response.data);
                    that.loaded = true;
                });

            },
            updateBill: function () {

                var that = this;
                this.form.put('/api/bills/' + this.$route.params.id).then(function (response) {
                    that.form.fill(response.data);
                })

            },
            deleteBill: function () {

                var that = this;
                this.form.delete('/api/bills/' + this.$route.params.id).then(function (response) {
                    that.form.fill(response.data);
                    that.$router.push('/super-admin/bills');
                })

            }
        }
    }
</script>
