<template>
    <!-- form section -->

    <form>
        <div class="right-content form1">
            <div id="contentRootPanel" class="fullpage">
                <div class="page-panel page-right-content A54VNK-be-a">
                    <div class="panel-body page-panel-body">
                        <div class="container-fluid A54VNK-Ae-e">
                            <div class="A54VNK-Ae-c"></div>
                            <div class="row">
                                <div class="col-sm-2 col-md-4 hidden-xs A54VNK-Ae-g"></div>
                                <div class="col-12 col-sm-9 col-md-8">
                                    <div class="form-horizontal">
                                        <div class="row form-group A54VNK-Ae-j">
                                            <div class="col-12 col-sm-6">
                                                <div class="btn-group A54VNK-tc-c switch-button" aria-atomic="true">
                                                    <a class='btn btn-primary active' aria-pressed="true" style="text-transform: capitalize;">Service</a>
                                                    <a class='btn btn-default' aria-pressed="false" style="text-transform: capitalize;">Product</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-2 hidden-xs A54VNK-Ae-g"></div>
                                <div class="col-12 col-md-10">
                                    <div class="form-group row">
                                        <div class="col-md-2 align-items-center d-flex justify-content-end tl">
                                            <label>Name <small style="color: red;padding-left: 4px;">*</small></label>
                                        </div>
                                        <div class="col-md-10">
                                            <input type="text" class="form-control" id="gwt-uid-116">
                                            <div class="error-panel"></div>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-md-2 align-items-center d-flex justify-content-end tl">
                                            <label>Unit</label>
                                        </div>
                                        <div class="col-md-10">
                                            <div class="dropdown">
                                                <input type="text" class="form-control A54VNK-oi-b" data-toggle="dropdown" autocomplete="off" role="button" placeholder="Search results" id="gwt-uid-123" aria-expanded="false">
                                                <ul class="dropdown-menu A54VNK-oi-a" style="max-height: 332px;">
                                                    <li class="active">
                                                        <a class="ellipsis-block" role="button" title="Piece"><strong>Piece</strong></a>
                                                    </li>
                                                    <li class="divider"></li>
                                                    <li class="">
                                                        <a class="ellipsis-block" role="button">Start the search</a>
                                                    </li>
                                                    <li class="">
                                                        <a class="ellipsis-block" role="button">Create a new...</a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-md-2 align-items-center d-flex justify-content-end tl">
                                            <label>Sale Price</label>
                                        </div>
                                        <div class="col-md-10">
                                            <input type="text" class="form-control" id="gwt-uid-125" style="text-align: right;" value='0.00'>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-md-2 align-items-center d-flex justify-content-end tl">
                                            <label>Purchase Price</label>
                                        </div>
                                        <div class="col-md-10">
                                            <input type="text" class="form-control" id="gwt-uid-126" style="text-align: right;" value='0.00'>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-md-2 A54VNK-Ae-g"></div>
                                <div class="col-12 col-md-10">
                                    <div class="row">
                                        <div class="col-12">
                                            <div class="form-group row">
                                                <div class="col-md-2 align-items-center d-flex justify-content-end tl">
                                                    <label>Item Number</label>
                                                </div>
                                                <div class="col-md-10">
                                                    <input type="text" class="form-control" id="gwt-uid-131">
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <div class="col-md-2 align-items-center d-flex justify-content-end tl">
                                                    <label>Description</label>
                                                </div>
                                                <div class="col-md-10">
                                                    <textarea class="form-control" rows="5" id="gwt-uid-132" style="resize: vertical; min-height: 50px;"></textarea>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <div class="col-md-2 align-items-center d-flex justify-content-end tl">
                                                    <label>Category/Family</label>
                                                </div>
                                                <div class="col-md-10">
                                                    <div class="dropdown">
                                                        <input type="text" class="form-control A54VNK-oi-b" data-toggle="dropdown" autocomplete="off" role="button" placeholder="Search results" id="gwt-uid-139" aria-expanded="false">
                                                        <ul class="dropdown-menu A54VNK-oi-a" style="max-height: 120px;">
                                                            <li class="active">
                                                                <a class="ellipsis-block" role="button" title="Miscellaneous"><strong>Miscellaneous</strong></a>
                                                            </li>
                                                            <li class="divider"></li>
                                                            <li class="">
                                                                <a class="ellipsis-block" role="button">Start the search</a>
                                                            </li>
                                                            <li class="">
                                                                <a class="ellipsis-block" role="button">Create a new...</a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-md-2 A54VNK-Ae-g"></div>
                                <div class="col-12 col-md-10">
                                    <div class="form-group row">
                                        <div class="col-md-2 align-items-center d-flex justify-content-end tl">
                                            <label>Track Inventory</label>
                                        </div>
                                        <div class="col-md-10">
                                            <div class="btn-group btn-group-toggle" data-toggle="buttons">
                                                <label class="btn active btn-default" for='option1' style="text-transform: capitalize;">
                                                    <input type="radio" checked=''>Yes
                                                </label>
                                                <label class="btn btn-default" for='option2' style="text-transform: capitalize;">
                                                    <input type="radio">No
                                                </label>
                                            </div>
                                            <input type="radio" id="option1" value="1" style="position: inherit;pointer-events: inherit">
                                            <input type="radio" id="option2" value="2" style="position: inherit;pointer-events: inherit">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-md-1 A54VNK-Ae-g"></div>
                                <div class="col-12 col-md-11">
                                    <div class="form-group row">
                                        <div class="col-md-3 align-items-center d-flex justify-content-end tl">
                                            <label>Valuation Costing</label>
                                        </div>
                                        <div class="col-md-9">
                                            <div class="A54VNK-ni-a">
                                                <div class="select-panel A54VNK-ni-c">
                                                    <select class="form-control" size="1" id="gwt-uid-149">
                                                        <option value="2">Standard Cost</option>
                                                        <option value="1">Weighted average price</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-md-3 align-items-center d-flex justify-content-end tl">
                                            <label>Authorize negative stock</label>
                                        </div>
                                        <div class="col-md-9">
                                            <div class="A54VNK-ni-a">
                                                <div class="select-panel A54VNK-ni-c">
                                                    <select class="form-control" size="1" id="gwt-uid-153">
                                                        <option value="2">No</option>
                                                        <option value="1">Yes</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-md-3 align-items-center d-flex justify-content-end tl">
                                            <label>Minimum Stock Quantity</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="text" class="form-control" id="gwt-uid-154" style="text-align: right;" value="0.00">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-md-3 align-items-center d-flex justify-content-end tl">
                                            <label>Receiving Location</label>
                                        </div>
                                        <div class="col-md-9">
                                            <div class="dropdown">
                                                <input type="text" class="form-control A54VNK-oi-b" data-toggle="dropdown" autocomplete="off" role="button" placeholder="Search results" id="gwt-uid-161" aria-expanded="false">
                                                <ul class="dropdown-menu A54VNK-oi-a">
                                                    <li class="active">
                                                        <a class="ellipsis-block" role="button" title="MAIN LOCATION">
                                                            <strong>MAIN</strong>
                                                            <strong>LOCATION</strong>
                                                        </a>
                                                    </li>
                                                    <li class="divider"></li>
                                                    <li class="">
                                                        <a class="ellipsis-block" role="button">Start the search</a>
                                                    </li>
                                                    <li class="">
                                                        <a class="ellipsis-block" role="button">Create a new...</a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-md-3 align-items-center d-flex justify-content-end tl">
                                            <label>Delivery Location</label>
                                        </div>
                                        <div class="col-md-9">
                                            <div class="dropdown">
                                                <input type="text" class="form-control A54VNK-oi-b" data-toggle="dropdown" autocomplete="off" role="button" placeholder="Search results" id="gwt-uid-161" aria-expanded="false">
                                                <ul class="dropdown-menu A54VNK-oi-a">
                                                    <li class="active">
                                                        <a class="ellipsis-block" role="button" title="MAIN LOCATION">
                                                            <strong>MAIN</strong>
                                                            <strong>LOCATION</strong>
                                                        </a>
                                                    </li>
                                                    <li class="divider"></li>
                                                    <li class="">
                                                        <a class="ellipsis-block" role="button">Start the search</a>
                                                    </li>
                                                    <li class="">
                                                        <a class="ellipsis-block" role="button">Create a new...</a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-md-3 align-items-center d-flex justify-content-end tl">
                                            <label>Inventory Account</label>
                                        </div>
                                        <div class="col-md-9">
                                            <div class="A54VNK-ni-a">
                                                <div class="select-panel A54VNK-ni-c">
                                                    <select class="form-control" size="1" id="gwt-uid-173">
                                                        <option value="11">12001 ( Inventory Miscellaneous )</option>
                                                        <option value="182">12900 ( Inventory in Transit )</option>
                                                    </select>
                                                </div>
                                                <button type="button" class="btn btn-link A54VNK-ni-b" style="">
                                                    <span class="picto-font"></span>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-md-3 align-items-center d-flex justify-content-end tl">
                                            <label>Inventory Transit Account</label>
                                        </div>
                                        <div class="col-md-9">
                                            <div class="A54VNK-ni-a">
                                                <div class="select-panel A54VNK-ni-c">
                                                    <select class="form-control" size="1" id="gwt-uid-176">
                                                        <option value="11">12001 ( Inventory Miscellaneous )</option>
                                                        <option value="182">12900 ( Inventory in Transit )</option>
                                                    </select>
                                                </div>
                                                <button type="button" class="btn btn-link A54VNK-ni-b" style="">
                                                    <span class="picto-font"></span>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <hr>
                            <a class="accordion-toggle collapsed A54VNK-ri-a" data-toggle="collapse" href="#gwt-uid-708">Advanced</a>
                            <div class="panel-collapse collapse" id="gwt-uid-708">
                                <div class="A54VNK-Ae-b">
                                    <div class="row">
                                        <div class="col-md-2 A54VNK-Ae-g"></div>
                                        <div class="col-12 col-md-10">
                                            <div class="form-group row">
                                                <div class="col-md-2 align-items-center d-flex justify-content-end tl">
                                                    <label>Private Note</label>
                                                </div>
                                                <div class="col-md-10">
                                                    <textarea class="form-control" rows="5" id="gwt-uid-181" style="resize: vertical; min-height: 50px;"></textarea>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <hr>
                                    <div class="row">
                                        <div class="col-md-1 A54VNK-Ae-g"></div>
                                        <div class="col-12 col-md-11">
                                            <div class="form-group row">
                                                <div class="col-md-3 align-items-center d-flex justify-content-end tl">
                                                    <label>COGS Account
                                                        <small style="color: red;padding-left: 4px;">*</small></label>
                                                </div>
                                                <div class="col-md-9">
                                                    <div class="dropdown">
                                                        <input type="text" class="form-control A54VNK-oi-b" data-toggle="dropdown" autocomplete="off" role="button" placeholder="Search results" id="gwt-uid-161" aria-expanded="false">
                                                        <ul class="dropdown-menu A54VNK-oi-a">
                                                            <li class="active">
                                                                <a class="ellipsis-block" role="button" title="Product Cost - Composition (51002)">
                                                                    Product Cost - Composition<span> (51002)</span>
                                                                </a>
                                                            </li>
                                                            <li class="no-hover">
                                                                <a class="ellipsis-block" role="button" title="Product Cost - Fabrication (51003)">
                                                                    Product Cost - Fabrication<span> (51003)</span>
                                                                </a>
                                                            </li>
                                                            <li class="no-hover">
                                                                <a class="ellipsis-block" role="button" title="Product Cost - Items (51001)">
                                                                    Product Cost - Items<span> (51001)</span>
                                                                </a>
                                                            </li>
                                                            <li class="no-hover">
                                                                <a class="ellipsis-block" role="button" title="Product Cost - Miscellaneous (51005)">
                                                                    Product Cost - Miscellaneous<span> (51005)</span>
                                                                </a>
                                                            </li>
                                                            <li class="no-hover">
                                                                <a class="ellipsis-block" role="button" title="Product Cost - Services (51004)">
                                                                    Product Cost - Services<span> (51004)</span>
                                                                </a>
                                                            </li>
                                                            <li class="divider"></li>
                                                            <li class="no-hover">
                                                                <a class="ellipsis-block" role="button">View all accounts</a>
                                                            </li>
                                                            <li class="">
                                                                <a class="ellipsis-block" role="button">Create an account</a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <div class="error-panel"></div>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <div class="col-md-3 align-items-center d-flex justify-content-end tl">
                                                    <label>Vat on Purchase</label>
                                                </div>
                                                <div class="col-md-9">
                                                    <div class="dropdown">
                                                        <input type="text" class="form-control A54VNK-oi-b" data-toggle="dropdown" autocomplete="off" role="button" placeholder="Search results" id="gwt-uid-161" aria-expanded="false">
                                                        <ul class="dropdown-menu A54VNK-oi-a">
                                                            <li class="active">
                                                                <a class="ellipsis-block" role="button" title="Product Cost - Composition (51002)">
                                                                    Product Cost - Composition<span> (51002)</span>
                                                                </a>
                                                            </li>
                                                            <li class="no-hover">
                                                                <a class="ellipsis-block" role="button" title="Product Cost - Fabrication (51003)">
                                                                    Product Cost - Fabrication<span> (51003)</span>
                                                                </a>
                                                            </li>
                                                            <li class="no-hover">
                                                                <a class="ellipsis-block" role="button" title="Product Cost - Items (51001)">
                                                                    Product Cost - Items<span> (51001)</span>
                                                                </a>
                                                            </li>
                                                            <li class="no-hover">
                                                                <a class="ellipsis-block" role="button" title="Product Cost - Miscellaneous (51005)">
                                                                    Product Cost - Miscellaneous<span> (51005)</span>
                                                                </a>
                                                            </li>
                                                            <li class="no-hover">
                                                                <a class="ellipsis-block" role="button" title="Product Cost - Services (51004)">
                                                                    Product Cost - Services<span> (51004)</span>
                                                                </a>
                                                            </li>
                                                            <li class="divider"></li>
                                                            <li class="no-hover">
                                                                <a class="ellipsis-block" role="button">View all accounts</a>
                                                            </li>
                                                            <li class="">
                                                                <a class="ellipsis-block" role="button">Create an account</a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <hr>
                                    <div class="row">
                                        <div class="col-md-1 A54VNK-Ae-g"></div>
                                        <div class="col-12 col-md-11">
                                            <div class="form-group row">
                                                <div class="col-md-3 align-items-center d-flex justify-content-end tl">
                                                    <label>
                                                        Income Account
                                                        <small style="color: red;padding-left: 4px;">*</small>
                                                    </label>
                                                </div>
                                                <div class="col-md-9">
                                                    <div class="dropdown">
                                                        <input type="text" class="form-control A54VNK-oi-b" data-toggle="dropdown" autocomplete="off" role="button" placeholder="Search results" id="gwt-uid-161" aria-expanded="false">
                                                        <ul class="dropdown-menu A54VNK-oi-a">
                                                            <li class="active">
                                                                <a class="ellipsis-block" role="button" title="Product Cost - Composition (51002)">
                                                                    Product Cost - Composition<span> (51002)</span>
                                                                </a>
                                                            </li>
                                                            <li class="no-hover">
                                                                <a class="ellipsis-block" role="button" title="Product Cost - Fabrication (51003)">
                                                                    Product Cost - Fabrication<span> (51003)</span>
                                                                </a>
                                                            </li>
                                                            <li class="no-hover">
                                                                <a class="ellipsis-block" role="button" title="Product Cost - Items (51001)">
                                                                    Product Cost - Items<span> (51001)</span>
                                                                </a>
                                                            </li>
                                                            <li class="no-hover">
                                                                <a class="ellipsis-block" role="button" title="Product Cost - Miscellaneous (51005)">
                                                                    Product Cost - Miscellaneous<span> (51005)</span>
                                                                </a>
                                                            </li>
                                                            <li class="no-hover">
                                                                <a class="ellipsis-block" role="button" title="Product Cost - Services (51004)">
                                                                    Product Cost - Services<span> (51004)</span>
                                                                </a>
                                                            </li>
                                                            <li class="divider"></li>
                                                            <li class="no-hover">
                                                                <a class="ellipsis-block" role="button">View all accounts</a>
                                                            </li>
                                                            <li class="">
                                                                <a class="ellipsis-block" role="button">Create an account</a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <div class="col-md-3 align-items-center d-flex justify-content-end tl">
                                                    <label>Vat on Sales</label>
                                                </div>
                                                <div class="col-md-9">
                                                    <div class="dropdown">
                                                        <input type="text" class="form-control A54VNK-oi-b" data-toggle="dropdown" autocomplete="off" role="button" placeholder="Search results" id="gwt-uid-161" aria-expanded="false">
                                                        <ul class="dropdown-menu A54VNK-oi-a">
                                                            <li class="active">
                                                                <a class="ellipsis-block" role="button" title="Product Cost - Composition (51002)">
                                                                    Product Cost - Composition<span> (51002)</span>
                                                                </a>
                                                            </li>
                                                            <li class="no-hover">
                                                                <a class="ellipsis-block" role="button" title="Product Cost - Fabrication (51003)">
                                                                    Product Cost - Fabrication<span> (51003)</span>
                                                                </a>
                                                            </li>
                                                            <li class="no-hover">
                                                                <a class="ellipsis-block" role="button" title="Product Cost - Items (51001)">
                                                                    Product Cost - Items<span> (51001)</span>
                                                                </a>
                                                            </li>
                                                            <li class="no-hover">
                                                                <a class="ellipsis-block" role="button" title="Product Cost - Miscellaneous (51005)">
                                                                    Product Cost - Miscellaneous<span> (51005)</span>
                                                                </a>
                                                            </li>
                                                            <li class="no-hover">
                                                                <a class="ellipsis-block" role="button" title="Product Cost - Services (51004)">
                                                                    Product Cost - Services<span> (51004)</span>
                                                                </a>
                                                            </li>
                                                            <li class="divider"></li>
                                                            <li class="no-hover">
                                                                <a class="ellipsis-block" role="button">View all accounts</a>
                                                            </li>
                                                            <li class="">
                                                                <a class="ellipsis-block" role="button">Create an account</a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <new-footer type="basic"/>
                </div>
            </div>
        </div>
    </form>

    <!-- form section -->
</template>

<script>
    import NewFooter from '../../../layouts/partials/new_footer'

    export default {
        components: {
            NewFooter,
        },
        name: 'Purchaseproductservice',
        data: function(){
            return {
                loaded: false,
                form: new Form({
                                        "id" : "",
                                        "is_services" : "",
                                        "name" : "",
                                        "unit" : "",
                                        "sales_price" : "",
                                        "purchase_price" : "",
                                        "item_number" : "",
                                        "description" : "",
                                        "family" : "",
                                        "private_note" : "",
                                        "income_account" : "",
                                        "vat_on_sales" : "",
                                        "is_track_inventory" : "",
                                        "valuation_costing" : "",
                                        "authorize_negative_stock" : "",
                                        "minimum_stock_quantity" : "",
                                        "receiving_location" : "",
                                        "picking_delivery_location" : "",
                                        "inventory_account" : "",
                                        "inventory_transit_account" : "",
                                        "net_weight" : "",
                                        "width" : "",
                                        "length" : "",
                                        "height" : "",
                                        "dimension_unit" : "",
                                        "cogs_account" : "",
                                        "vat_on_purchases" : "",
                                        "created_at" : "",
                                        "updated_at" : "",
                                    })
            }
        },
        created: function(){
            this.getPurchaseproductservice();
        },
        methods: {
            getPurchaseproductservice: function(Purchaseproductservice){

                var that = this;
                this.form.get('/api/purchaseproductservices/'+this.$route.params.id).then(function(response){
                    that.form.fill(response.data);
                    that.loaded = true;
                });

            },
            updatePurchaseproductservice: function(){

                var that = this;
                this.form.put('/api/purchaseproductservices/'+this.$route.params.id).then(function(response){
                    that.form.fill(response.data);
                })

            },
            deletePurchaseproductservice: function(){

                var that = this;
                this.form.delete('/api/purchaseproductservices/'+this.$route.params.id).then(function(response){
                    that.form.fill(response.data);
                    that.$router.push('/super-admin/purchaseproductservices');
                })

            }
        }
    }
</script>
