<template>
    <table>
        <tr v-for="i in 10" :key="i">
            <td>name</td>
            <td>roll</td>
            <td>class</td>
            <td>teacher</td>
        </tr>
    </table>
</template>

<script>
export default {

}
</script>

<style>

</style>

