<template>
    <div>
        <sub-header type="basic"/>
        <!-- full table -->

        <section class="content content-menu">
            <div class="container-fluid">
                <!-- breadcumbs -->
                <div class="block-header">
                    <div class="row">
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                            <ul class="breadcrumb breadcrumb-style d-inline-block mb-0">
                                <li class="breadcrumb-item">
                                    <h4 style="border: 0;" class="page-title">Clearing &amp; Forwarding Agents</h4>
                                </li>
                            </ul>
                            <ul class="d-inline-block mb-0" style="float: right;padding: .75rem 1rem;">
                                <li style="float: left;">
                                    <router-link to="/contact/cf-agent/create" class="btn btn-default m-0 mr-2 mb-2 mb-lg-0 mobile_d_none">New C&amp;F Agent</router-link>
                                    <router-link to="/contact/cf-agent/create" class="btn btn-default m-0 mr-2 mb-2 mb-lg-0 mobile_d_block"><i class="fas fa-plus"></i></router-link>
                                </li>
                                <li class="mobile_d_search_block" style="float: left;">
                                    <a class="btn btn-white nav-link m-0 mr-2">
                                        <i class="fas fa-search" aria-hidden="true"></i>
                                    </a>
                                </li>
                                <li style="float: left;">
                                    <a class="btn btn-white new_dot nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i class="fa fa-ellipsis-v" aria-hidden="true"></i>
                                    </a>
                                    <div class="dropdown-menu new_dropdown" aria-labelledby="navbarDropdown">
                                        <a class="dropdown-item" href="#">Export C&F Agent Lines</a>
                                        <a class="dropdown-item" href="#">Export C&F Agent Details</a>
                                        <a class="dropdown-item" href="#">All working Port</a>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <!-- breadcumbs -->

                <!-- filter -->

                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12  mobile_d_search_none">
                        <div class="card filter" style="margin-bottom: 13px;">
                            <div class="body">
                                <!-- Filter Panel -->
                                <div class="row">
                                    <div class="col-md-4 mb-0 d-flex align-content-center flex-wrap">
                                        <div class="setting_li_search">
                                            <i class="fas fa-search"></i>
                                            <input type="text" placeholder="Search in Clearing & Forwarding Agents">
                                        </div>
                                    </div>
                                    <div class="col-md-8 mb-0 text-right">
                                        <button class="btn btn-outline-default"> All Employees
                                            <i class="fa fa-angle-down" aria-hidden="true"></i></button>
                                        <!-- <button class="btn btn-outline-default"> All Customers <i class="fa fa-angle-down" aria-hidden="true"></i></button> -->
                                        <button class="btn btn-outline-default"> Any Date
                                            <i class="fa fa-angle-down" aria-hidden="true"></i></button>
                                    </div>
                                </div>
                                <!-- Filter Panel -->
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mobile_d_search_block">
                        <div class="card filter" style="margin-bottom: 13px;">
                            <div class="body">
                                <!-- Filter Panel -->
                                <div class="row">
                                    <div class="col-md-12 mb-0 d-flex align-content-center flex-wrap">
                                        <div class="setting_li_search">
                                            <i class="fas fa-search"></i>
                                            <input type="text" placeholder="Search in Clearing & Forwarding Agents">
                                        </div>
                                    </div>
                                </div>
                                <!-- Filter Panel -->
                            </div>
                        </div>
                    </div>
                </div>

                <!-- filter -->

                <!-- table -->

                <div class="row clearfix">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th style="width: 5%;padding: 5px;">
                                            <div class="input-group-prepend">
                                                <div class="input-group-text">
                                                    <label>
                                                        <input type="checkbox" class="filled-in">
                                                        <span></span>
                                                    </label>
                                                </div>
                                            </div>
                                        </th>
                                        <th style="min-width: 125px;">Name</th>
                                        <th style="min-width: 125px;">Address</th>
                                        <th style="min-width: 125px;">Email</th>
                                        <th style="min-width: 125px;">Phones</th>
                                        <th class="text-center" style="min-width: 145px;">C&F Agent Number</th>
                                        <th class="text-center" style="min-width: 200px;">Notes</th>
                                        <th class="text-center" style="width: 70px;min-width: 70px;"></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr v-for="cfagetn in cfagetns">
                                        <td style="padding: 5px 5px 4px;">
                                            <div class="input-group-prepend">
                                                <div class="input-group-text">
                                                    <label>
                                                        <input type="checkbox" class="filled-in">
                                                        <span></span>
                                                    </label>
                                                </div>
                                            </div>
                                        </td>
                                        <td @click="cfagetnsEdit(cfagetn)" style="cursor: pointer;">
                                            <div class="ellipsis" >
                                                {{ cfagetn.company_name }}
                                            </div>
                                        </td>
                                        <td @click="cfagetnsEdit(cfagetn)" style="cursor: pointer;">
                                            <div class="ellipsis">
                                                {{ cfagetn.billing_address }}
                                                {{ cfagetn.line_2 }}
                                                {{ cfagetn.city }}
                                                {{ cfagetn.zip_code }}
                                                {{ cfagetn.country_name.name }}
                                            </div>
                                        </td>
                                        <td @click="cfagetnsEdit(cfagetn)" style="cursor: pointer;">
                                            <div class="ellipsis">
                                                {{ cfagetn.email }}
                                            </div>
                                        </td>
                                        <td @click="cfagetnsEdit(cfagetn)" style="cursor: pointer;">
                                            <div class="ellipsis">
                                                {{ cfagetn.phone }}
                                            </div>
                                        </td>
                                        <td class="text-center" @click="cfagetnsEdit(cfagetn)" style="cursor: pointer;">
                                            <div class="ellipsis">
                                                {{ cfagetn.business_code }}
                                            </div>
                                        </td>
                                        <td class="text-center" @click="cfagetnsEdit(cfagetn)" style="cursor: pointer;">
                                            <div class="ellipsis">
                                                {{ cfagetn.note }}
                                            </div>
                                        </td>
                                        <td class="action" style="text-align:right;padding-top: 6px;padding-bottom: 6px;">
                                            <div class="dropdown d-inline-block">
                                                <div class="btn-group dropleft text-center">
                                                    <a href="#" onclick="return false;" class="btn btn-white dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                                        <i class="fa fa-ellipsis-v" aria-hidden="true"></i>
                                                    </a>
                                                    <div class="dropdown-menu">
                                                        <a class="dropdown-item text-danger waves-effect waves-light"  @click="deleteCfagetn(cfagetn.id)">Delete</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- full table -->
    </div>
</template>


<script>
    import SubHeader from "../sub_header";

    export default {
        components: {
            SubHeader,
        },

        name: 'Cfagetn',

        data: function () {
            return {
                cfagetns: false,
                form: new Form({
                    "id": "",
                    "company_name": "",
                    "email": "",
                    "phone": "",
                    "cf_license_number": "",
                    "website": "",
                    "billing_address": "",
                    "line_2": "",
                    "city": "",
                    "zip_code": "",
                    "country": "18",
                    "working_port": true,
                    "delivery_address": [{
                        address: '',
                    }],
                    "contacts": [],
                    "payment_terms": "",
                    "price_family": "",
                    "currency": "18",
                    "business_code": "",
                    "opt_in_to_emails": true,
                    "assigned_to": "0",
                    "reference_account": "",
                    "starting_balance": "",
                    "date_as": new Date().toLocaleString(),
                    "note": "",
                    "files": [],
                    "created_at": "",
                    "updated_at": "",
                })
            }
        },
        created: function () {
            this.listCfagetns();
        },
        methods: {
            listCfagetns: function () {
                axios.get('/api/cfagetns').then(response => this.cfagetns = response.data);
            },
            cfagetnsEdit(cfagetn){
                this.$router.replace({ name: 'editCfAgetns', params: { id: cfagetn.id }});
            },
            deleteCfagetn: function (id) {
                Swal.fire({
                    title: 'Are you sure?',
                    text: "You won't be able to revert this!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    if (result.value) {
                        this.form.delete('/api/cfagetns/' + id).then(() => {
                            Toast.fire({
                                icon: 'success',
                                title: 'Deleted successfully'
                            });
                            this.listCfagetns();
                        }).catch(() => {
                            Toast.fire({
                                icon: 'error',
                                title: 'Something went wrong'
                            });
                        });
                    }
                })
            }
        }
    }
</script>
