<template>
    <!-- form section -->
    <form @submit.prevent="updateSupplier">
        <div class="right-content form2">
            <div id="contentRootPanel" class="fullpage">
                <div class="page-panel page-right-content A54VNK-be-a">
                    <div class="panel-body page-panel-body">
                        <div class="container-fluid A54VNK-Ae-e">
                            <div class="A54VNK-Ae-c"></div>
                            <div class="row">
                                <div class="col-sm-2 col-md-3 hidden-xs A54VNK-Ae-g">
                                    <h4> Overview </h4>
                                </div>
                                <div class="col-12 col-sm-9 col-md-8">
                                    <div class="form-horizontal">
                                        <input type="hidden" v-model="form.id"></input>
                                        <div class="row form-group A54VNK-Ae-j">
                                            <div class="col-12 col-sm-6">
                                                <div class="btn-group A54VNK-tc-c switch-button" aria-atomic="true">
                                                    <a class="btn btn-default" v-bind:class="{ active: form.is_company }" v-on:click="form.is_company = true" aria-pressed="true" style="text-transform: capitalize;">Company</a>
                                                    <a class="btn btn-default" v-bind:class="{ active: !form.is_company }" v-on:click="form.is_company = false" aria-pressed="false" style="text-transform: capitalize;">Individual</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-12 col-sm-12" v-if="form.is_company == true">
                                            <div class="form-group floating-label mandatory" :class="{ 'has-error': form.errors.has('company_name') }">
                                                <input type="text" v-model="form.company_name" class="form-control form-component" id="gwt-uid-384" autocomplete="off">
                                                <label  class="control-label form-question ellipsis" :class="{ 'activess': form.company_name != null }" for="gwt-uid-384">Company Name</label>
                                            </div>
                                            <div v-if="form.errors.has('company_name')" class="required-text" v-html="form.errors.get('company_name')"></div>
                                        </div>

                                        <div class="col-12 col-offset-0 col-sm-6 col-sm-offset-0" aria-hidden="true" v-if="form.is_company == false">
                                            <div class="form-group floating-label" :class="{ 'has-error': form.errors.has('first_name') }">
                                                <input type="text" v-model="form.first_name" class="form-control form-component" id="gwt-uid-380" autocomplete="off">
                                                <label class="control-label form-question ellipsis" :class="{ 'activess': form.first_name != null }" for="gwt-uid-380">First Name</label>
                                            </div>
                                            <div v-if="form.errors.has('first_name')" class="required-text" v-html="form.errors.get('first_name')"></div>
                                        </div>

                                        <div class="col-12 col-offset-0 col-sm-6 col-sm-offset-0" aria-hidden="true" v-if="form.is_company == false">
                                            <div class="form-group floating-label" :class="{ 'has-error': form.errors.has('last_name') }">
                                                <input type="text" v-model="form.last_name" class="form-control form-component" id="gwt-uid-388" autocomplete="off">
                                                <label class="control-label form-question ellipsis" :class="{'activess': form.last_name != null}" for="gwt-uid-388">Last Name</label>
                                            </div>
                                            <div v-if="form.errors.has('last_name')" class="required-text" v-html="form.errors.get('last_name')"></div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-12 col-sm-6">
                                            <div class="form-group floating-label">
                                                <input type="text" v-model="form.email" class="form-control form-component" id="gwt-uid-430" autocomplete="off">
                                                <label class="control-label form-question ellipsis" :class="{'activess': form.email != null}" for="gwt-uid-430">Email</label>
                                            </div>
                                        </div>
                                        <div class="col-12 col-sm-6">
                                            <div class="form-group floating-label">
                                                <input type="text" v-model="form.phone" class="form-control form-component" id="gwt-uid-426" autocomplete="off">
                                                <label class="control-label form-question ellipsis" :class="{'activess': form.phone != null}" for="gwt-uid-426">Phone Number</label>
                                            </div>
                                        </div>
                                        <div class="col-12 col-sm-6">
                                            <div class="form-group floating-label">
                                                <input type="text" v-model="form.vat_number" class="form-control form-component" id="gwt-uid-467" autocomplete="off">
                                                <label class="control-label form-question ellipsis" :class="{'activess': form.vat_number != null}" for="gwt-uid-467">NID / TIN / VAT</label>

                                            </div>
                                        </div>
                                        <div class="col-12 col-sm-6">
                                            <div class="form-group floating-label">
                                                <input type="text" v-model="form.website" class="form-control form-component" id="gwt-uid-434" autocomplete="off">
                                                <label class="control-label form-question ellipsis" :class="{'activess': form.website != null}" for="gwt-uid-434">Website</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-12 col-sm-2 col-md-3 A54VNK-Ae-g">
                                    <h4> Address </h4>
                                </div>
                                <div class="col-12 col-sm-9 col-md-8">
                                    <div class="row">
                                        <div class="col-12">
                                            <div>
                                                <span></span>
                                                <div>
                                                    <div class="row">
                                                        <div class="col-12">
                                                            <div class="form-group floating-label">
                                                                <input type="text" v-model="form.billing_address" class="form-control form-component pac-target-input" id="gwt-uid-392" autocomplete="off">
                                                                <label class="control-label form-question ellipsis" :class="{'activess': form.billing_address != null}" for="gwt-uid-392">Billing address</label>
                                                            </div>
                                                        </div>
                                                        <div class="col-12">
                                                            <div class="form-group floating-label">
                                                                <input type="text" v-model="form.line_2" class="form-control form-component" id="gwt-uid-396" autocomplete="off">
                                                                <label class="control-label form-question ellipsis" :class="{'activess': form.line_2 != null}" for="gwt-uid-396">Line 2</label>
                                                            </div>
                                                        </div>
                                                        <div class="col-12">
                                                            <div class="row">
                                                                <div class="col-12 col-sm-4">
                                                                    <div class="form-group floating-label">
                                                                        <input type="text" v-model="form.city" class="form-control form-component" id="gwt-uid-415" autocomplete="off">
                                                                        <label class="control-label form-question ellipsis" :class="{'activess': form.city != null}" for="gwt-uid-415">City</label>

                                                                    </div>
                                                                </div>
                                                                <div class="col-12 col-sm-4">
                                                                    <div class="form-group floating-label">
                                                                        <input type="text" v-model="form.zip_code" class="form-control form-component" id="gwt-uid-411" autocomplete="off">
                                                                        <label class="control-label form-question ellipsis" :class="{'activess': form.zip_code != null}" for="gwt-uid-411">Postal/Zip Code</label>

                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-12 col-sm-6">
                                                            <div class="form-group floating-label focused">
                                                                <div class="select-panel form-component">
                                                                    <select class="form-control" id="gwt-uid-400" v-model="form.country">
                                                                        <option v-for="(country,index) in countries" :key="country.id" :value="country.id">{{ country.name }}</option>
                                                                    </select>
                                                                    <label class="control-label form-question ellipsis" for="gwt-uid-400" style="top: -6px;">Country</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-12 col-sm-2 col-md-3 A54VNK-Ae-g">
                                    <h4> Contacts </h4>
                                </div>
                                <div class="col-12 col-sm-9 col-md-8">
                                    <div class="row">
                                        <div class="col-12">
                                            <div class="A54VNK-Ef-b">
                                                <div>
                                                    <div class="text-muted text-left" style="margin-top: 10px;" v-if="form.contacts.length == 0">No items to show</div>
                                                    <div class="row A54VNK-Pg-e" v-for="(contact, l) in form.contacts" :key="l">
                                                        <div class="col-sm-10 hidden-xs A54VNK-Pg-f">
                                                            <div class="row">
                                                                <div class="col-sm-3 object-list-first-cell">
                                                                    <div class="form-group floating-label">
                                                                        <div class="dropdown form-component">
                                                                            <input type="text" v-model="form.contacts[l].first_name" class="form-control form-component" data-toggle="dropdown" :id="'first_name-'+l" autocomplete="off">
                                                                            <label class="control-label form-question ellipsis" :class="{'activess': form.contacts[l].first_name != null}" :for="'first_name-'+l">First Name</label>
                                                                            <ul class="dropdown-menu A54VNK-ge-d">
                                                                                <li class="">
                                                                                    <a class="ellipsis-block" role="button"></a>
                                                                                </li>
                                                                            </ul>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-3 object-list-cell">
                                                                    <div class="form-group floating-label mandatory" :class="{ 'has-error': form.errors.has('contacts.'+[l]+'.last_name') }">
                                                                        <input type="text" v-model="form.contacts[l].last_name" class="form-control form-component" :id="'last_name-'+l" autocomplete="off">
                                                                        <label class="control-label form-question ellipsis" :class="{'activess': form.contacts[l].last_name != null}" :for="'last_name-'+l">Last Name</label>
                                                                    </div>
                                                                    <div v-if="form.errors.has('contacts.'+[l]+'.last_name')" class="required-text" v-html="form.errors.get('contacts.'+[l]+'.last_name')"></div>
                                                                </div>
                                                                <div class="col-sm-3 object-list-cell">
                                                                    <div class="form-group floating-label">
                                                                        <input type="text" v-model="form.contacts[l].email" class="form-control form-component" :id="'email-'+l" autocomplete="off">
                                                                        <label class="control-label form-question ellipsis" :class="{'activess': form.contacts[l].email != null}" :for="'email-'+l">Email</label>
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-3 object-list-cell">
                                                                    <div class="form-group floating-label">
                                                                        <input type="text" v-model="form.contacts[l].phone" class="form-control form-component" :id="'phone-'+l" autocomplete="off">
                                                                        <label class="control-label form-question ellipsis" :class="{'activess': form.contacts[l].phone != null}" :for="'phone-'+l">Phone</label>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-4 col-sm-2 text-right object-list-last-cell A54VNK-Pg-a">
                                                            <button @click="removeContactListRow(l, contact)" type="button" class="btn btn-danger A54VNK-Pg-b">
                                                                <span class="picto-font">#</span>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                                <button @click="addContactListRow()" type="button" class="btn btn-default A54VNK-Ef-a"  style="text-transform: capitalize;">New Supplier Contact</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <hr>
                            <a class="accordion-toggle collapsed A54VNK-Ae-a" data-toggle="collapse" href="#gwt-uid-708">Advanced</a>
                            <div class="panel-collapse collapse" id="gwt-uid-708">
                                <div class="A54VNK-Ae-b">
                                    <div class="row">
                                        <div class="col-12 col-sm-2 col-md-3 A54VNK-Ae-g">
                                            <h4> Finance </h4>
                                        </div>
                                        <div class="col-12 col-sm-9 col-md-8">
                                            <div class="row">
                                                <div class="col-12 col-sm-6">
                                                    <div class="form-group floating-label focused">
                                                        <div class="dropdown form-component">
                                                            <input v-model="form.payment_terms" type="text" class="form-control A54VNK-ge-i" id="gwt-uid-450" data-toggle="dropdown" placeholder='Payment Terms' autocomplete="off" style="padding-top: 0px !important;">
                                                            <label class="control-label form-question ellipsis not_float" for="gwt-uid-450">Payment Terms</label>
                                                            <ul class="dropdown-menu A54VNK-ge-d">
                                                                <li @click="getPaymentTerms('Due on receipt')"><a class="ellipsis-block" role="button">Due on receipt</a></li>
                                                                <li @click="getPaymentTerms('At 30 days')"><a class="ellipsis-block" role="button">At 30 days</a></li>
                                                                <li @click="getPaymentTerms('At 90 days')"><a class="ellipsis-block" role="button">At 90 days</a></li>
                                                                <li @click="getPaymentTerms('In two installments')"><a class="ellipsis-block" role="button">In two installments</a></li>
                                                                <li @click="getPaymentTerms('In three installments')"><a class="ellipsis-block" role="button">In three installments</a></li>
                                                                <li class="divider"></li>
                                                                <li><a class="ellipsis-block" role="button">Create a new...</a></li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-12 col-sm-6" aria-hidden="true">
                                                    <div class="form-group floating-label focused">
                                                        <div class="select-panel form-component">
                                                            <select class="form-control" id="gwt-uid-455" v-model="form.currency">
                                                                <option v-for="currency in countries" v-if="currency.currency_code != ''" :value="currency.id">{{ currency.currency_code }}</option>
                                                            </select>
                                                            <label class="control-label form-question ellipsis" for="gwt-uid-455" style="top: -6px;">Currency</label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <hr>
                                    <div class="row">
                                        <div class="col-12 col-sm-2 col-md-3 A54VNK-Ae-g">
                                            <h4> Business </h4>
                                        </div>
                                        <div class="col-12 col-sm-9 col-md-8">
                                            <div class="row">
                                                <div class="col-12 col-sm-6">
                                                    <div class="form-group floating-label" :class="{ 'has-error': form.errors.has('business_code') }">
                                                        <input v-model="form.business_code" type="text" class="form-control form-component" id="gwt-uid-459" autocomplete="off">
                                                        <label class="control-label form-question ellipsis" :class="{'activess': form.business_code != null}" for="gwt-uid-459">Code</label>
                                                    </div>
                                                    <div v-if="form.errors.has('business_code')" class="required-text" v-html="form.errors.get('business_code')"></div>
                                                </div>
                                                <div class="col-12 col-sm-6" aria-hidden="true">
                                                    <div class="form-group floating-label focused">
                                                        <div class="select-panel form-component">
                                                            <select class="form-control" id="gwt-uid-164" v-model="form.assigned_to">
                                                                <option value="0">none</option>
                                                                <option>employee name</option>
                                                            </select>
                                                            <label class="control-label form-question ellipsis" for="gwt-uid-164" style="top: -6px;">Assigned To</label>
                                                        </div>

                                                    </div>
                                                </div>
                                                <div class="col-12 col-sm-6">
                                                    <div class="row A54VNK-uc-a">
                                                        <div class="col-6"><span class="control-label">Opt-in to Emails</span></div>
                                                        <div class="col-6 text-right">
                                                            <div class="btn-group btn-group-toggle" data-toggle="buttons">
                                                                <label v-on:click="form.opt_in_to_emails = true" class="btn btn-default" v-bind:class="{ active: form.opt_in_to_emails }" for='opt_email1' style="text-transform: capitalize;">
                                                                    <input type="radio" id="opt_email1" value="true" v-model="form.opt_in_to_emails">Yes
                                                                </label>
                                                                <label v-on:click="form.opt_in_to_emails = false" class="btn btn-default" v-bind:class="{ active: !form.opt_in_to_emails }" for='opt_email2' style="text-transform: capitalize;">
                                                                    <input type="radio" id="opt_email2" value="false" v-model="form.opt_in_to_emails">No
                                                                </label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-12 col-sm-6">
                                                    <div class="form-group floating-label focused">
                                                        <div class="dropdown form-component">
                                                            <input v-model="form.reference_account" type="text" class="form-control A54VNK-ge-i" id="gwt-uid-484" data-toggle="dropdown" placeholder='Create an account based on another account' autocomplete="off" style="padding-top: 0px !important;">
                                                            <label class="control-label form-question ellipsis not_float" for="gwt-uid-484">Create an account based on another account</label>
                                                            <ul class="dropdown-menu A54VNK-ge-d">
                                                                <li @click="getReferenceAccount('11100 (Accounts Receivable:Miscellaneous Customers)')"><a class="ellipsis-block" role="button">11100 (Accounts Receivable:Miscellaneous Customers)</a></li>
                                                                <li @click="getReferenceAccount('11100 CUS-002 (company1)')"><a class="ellipsis-block" role="button">11100 CUS-002 (company1)</a></li>
                                                                <li @click="getReferenceAccount('11400 (Other Receivables)')"><a class="ellipsis-block" role="button">11400 (Other Receivables)</a></li>
                                                                <li @click="getReferenceAccount('11500 (Allowance for Doubtful Account)')"><a class="ellipsis-block" role="button">11500 (Allowance for Doubtful Account)</a></li>
                                                            </ul>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <hr>
                                    <div class="row">
                                        <div class="col-12 col-sm-2 col-md-3 A54VNK-Ae-g">
                                            <h4> Notes </h4>
                                        </div>
                                        <div class="col-12 col-sm-9 col-md-8">
                                            <div class="form-group floating-label form-group-textarea">
                                                <textarea v-model="form.note" class="form-control form-component" id="gwt-uid-488" autocomplete="off" rows="10"></textarea>
                                                <label class="control-label form-question ellipsis" for="gwt-uid-488">Notes</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <new-footer type="basic"/>
                </div>
            </div>
        </div>
    </form>
    <!-- form section -->
</template>

<script>

    import NewFooter from '../../../layouts/partials/new_footer'

    export default {
        components: {
            NewFooter,
        },
        name: 'Supplier',
        data: function () {
            return {
                countries: '',
                loaded: false,
                form: new Form({
                    "id": "",
                    "is_company": true,
                    "company_name": "",
                    "first_name": "",
                    "last_name": "",
                    "middle_name": "",
                    "email": "",
                    "phone": "",
                    "website": "",
                    "vat_number": "",
                    "billing_address": "",
                    "line_2": "",
                    "city": "",
                    "zip_code": "",
                    "country": "18",
                    "contacts": [],
                    "payment_terms": "",
                    "currency": "18",
                    "business_code": "",
                    "opt_in_to_emails": true,
                    "assigned_to": "0",
                    "reference_account": "",
                    "note": "",
                    "created_at": "",
                    "updated_at": "",
                })
            }
        },
        created: function () {
            this.getCountryList();
            this.getSuppliersSingle();
        },
        methods: {
            getCountryList: function () {
                axios.get('/api/country-list').then(response => this.countries = response.data);
            },
            getSuppliersSingle: function (Suppliers) {
                var that = this;
                this.form.get('/api/suppliers/' + this.$route.params.id).then(function (response) {
                    that.form.fill(response.data);
                });

            },
            updateSupplier: function () {
                this.form.put('/api/suppliers/'+this.form.id).then(() => {
                    Toast.fire({
                        icon: 'success',
                        title: 'Update successfully'
                    });
                    this.$router.replace({ name: 'supplierLists'});
                    this.form.reset();
                }).catch(() => {
                    Toast.fire({
                        icon: 'error',
                        title: 'Error Created'
                    });
                });

            },
            getPaymentTerms(value) {
                this.form.payment_terms = value;
            },
            getReferenceAccount(value) {
                this.form.reference_account = value;
            },
            removeContactListRow(l, contact) {
                if (l > -1) {
                    this.form.contacts.splice(l, 1);
                }
            },
            addContactListRow() {
                this.form.contacts.push({
                    first_name : '',
                    last_name : '',
                    email : '',
                    phone : '',
                });
            },
        }
    }
</script>
