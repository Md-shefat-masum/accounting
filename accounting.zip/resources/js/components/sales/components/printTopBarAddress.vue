<template>
    <div>
        <h4>Orika Corporation</h4>
        <p>218/3/A (3rd floor) West Kafrul,</p>
        <p>Begum Rokeya Ave,Shwerapara</p>
        <p>Dhaka 1216</p>
        <p>Phone: +8809638786786</p>
        <p>Mobile: +8801712662245</p>
        <p>www.orika.com.bd</p>
    </div>
</template>

<script>
export default {

}
</script>

<style>

</style>

