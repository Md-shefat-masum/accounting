<template>
    <!-- form section -->

    <form>
        <div class="right-content form1">
            <div id="contentRootPanel" class="fullpage">
                <div class="A54VNK-ce-a">
                    <div class="page-panel panel-default page-right-content">
                        <div>
                            <div class="panel-body page-panel-body">
                                <div class="container-fluid">
                                    <div class="row">
                                        <div class="col-xs-12 col-sm-2 A54VNK-Re-e"><h4>Overview</h4></div>
                                        <div class="col-xs-12 col-sm-10">
                                            <div class="row">
                                                <div class="col-xs-12 col-sm-6">
                                                    <div class="form-group floating-label form-group-textarea">
                                                        <textarea class="form-control form-component A54VNK-Gb-b" placeholder="Description" id="gwt-uid-4413" autocomplete="off" rows="1"></textarea>
                                                        <!-- <label class="control-label form-question ellipsis" for="gwt-uid-4413">Description</label> -->
                                                        <div class="error-panel"></div>
                                                    </div>
                                                </div>
                                                <div class="col-xs-12 col-sm-4">
                                                    <div class="form-group floating-label mandatory focused">
                                                        <div class="form-component A54VNK-ud-c d-flex">
                                                            <input type="text" class="form-control" placeholder="Date" id="gwt-uid-4409" />
                                                            <!-- <label class="control-label form-question ellipsis" for="gwt-uid-4409">Date</label> -->
                                                            <div class="input-group-btn A54VNK-ud-d">
                                                                <button type="button" class="btn btn-default" tabindex="-1"><span class="picto-font">\</span></button>
                                                            </div>
                                                        </div>
                                                        <div class="error-panel"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <hr />
                                    <div class="row">
                                        <div class="col-xs-12 col-sm-2 A54VNK-Re-e"><h4>Accounts</h4></div>
                                        <div class="col-xs-12 col-sm-10">
                                            <div class="row">
                                                <div class="col-xs-12 col-sm-5">
                                                    <div class="form-group floating-label mandatory">
                                                        <div class="dropdown form-component">
                                                            <!-- <a class="A54VNK-se-b"><span class="picto-font">D</span>
                                                            </a> -->
                                                            <input type="text" class="form-control A54VNK-se-i" placeholder="From Account" id="gwt-uid-4435" data-toggle="dropdown" autocomplete="off" />
                                                            <label class="control-label form-question ellipsis" for="gwt-uid-4435">From Account</label>
                                                            <ul class="dropdown-menu A54VNK-se-d">
                                                                <li class="active"><a class="ellipsis-block" role="button">city bank</a></li>
                                                                <li class=""><a class="ellipsis-block" role="button">asia bank</a></li>
                                                                <li class="divider"></li>
                                                                <li class=""><a class="ellipsis-block" role="button">New Bank</a></li>
                                                            </ul>
                                                            <div class="error-panel"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-xs-12 col-sm-5">
                                                    <div class="form-group floating-label mandatory">
                                                        <div class="dropdown form-component">
                                                            <!-- <a class="A54VNK-se-b"><span class="picto-font">D</span></a>  -->
                                                            <input type="text" class="form-control A54VNK-se-i" placeholder="To Account" id="gwt-uid-4458" data-toggle="dropdown" autocomplete="off" />
                                                            <label class="control-label form-question ellipsis" for="gwt-uid-4458">To Account</label>
                                                            <ul class="dropdown-menu A54VNK-se-d">
                                                                <li class="active"><a class="ellipsis-block" role="button">city bank</a></li>
                                                                <li class=""><a class="ellipsis-block" role="button">asia bank</a></li>
                                                                <li class="divider"></li>
                                                                <li class=""><a class="ellipsis-block" role="button">New Bank</a></li>
                                                            </ul>
                                                            <div class="error-panel"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <hr />
                                    <div class="row">
                                        <div class="col-xs-12 col-sm-2 A54VNK-Re-e"><h4>Amount</h4></div>
                                        <div class="col-xs-12 col-sm-10">
                                            <div class="row">
                                                <div class="col-xs-12 col-sm-5">
                                                    <div class="form-group floating-label mandatory">
                                                        <input type="text" class="form-control form-component" placeholder="Amount" id="gwt-uid-4425" autocomplete="off" /> <label class="control-label form-question ellipsis" for="gwt-uid-4425">Amount</label>
                                                        <div class="error-panel"></div>
                                                    </div>
                                                </div>
                                                <div class="col-xs-12 col-sm-5" aria-hidden="true" style="display: none;">
                                                    <div class="form-group floating-label mandatory">
                                                        <input type="text" class="form-control form-component" placeholder="Amount" id="gwt-uid-4448" autocomplete="off" /> <label class="control-label form-question ellipsis" for="gwt-uid-4448">Amount</label>
                                                        <div class="error-panel"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <hr />
                                    <div class="row">
                                        <div class="col-xs-12 col-sm-2 A54VNK-Re-e"><h4>Result</h4></div>
                                        <div class="col-xs-12 col-sm-10">
                                            <div class="row A54VNK-Re-d">
                                                <div class="col-xs-12 col-sm-5">
                                                    <div class="row A54VNK-Re-c row">
                                                        <div class="col-12">
                                                            <div class="A54VNK-Re-a">No bank selected</div>
                                                        </div>
                                                        <div class="col-12">
                                                            <div class="form-group A54VNK-qg-a d-flex justify-content-between">
                                                                <span for="gwt-uid-4417">Available Balance</span>
                                                                <div class="gwt-Label" id="gwt-uid-4417">0.00</div>
                                                                <!-- <div class="error-panel"></div> -->
                                                            </div>
                                                        </div>
                                                        <div class="col-12">
                                                            <div class="form-group A54VNK-qg-a d-flex justify-content-between">
                                                                <span for="gwt-uid-4421">Balance After Transfer</span>
                                                                <div class="gwt-Label" id="gwt-uid-4421">0.00</div>
                                                                <!-- <div class="error-panel"></div> -->
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-xs-12 col-sm-5">
                                                    <div class="row">
                                                        <div class="col-12">
                                                            <div class="A54VNK-Re-a">No bank selected</div>
                                                        </div>
                                                        <div class="col-12">
                                                            <div class="form-group A54VNK-qg-a d-flex justify-content-between">
                                                                <span for="gwt-uid-4440">Available Balance</span>
                                                                <div class="gwt-Label" id="gwt-uid-4440">0.00</div>
                                                                <!-- <div class="error-panel"></div> -->
                                                            </div>
                                                        </div>
                                                        <div class="col-12">
                                                            <div class="form-group A54VNK-qg-a d-flex justify-content-between">
                                                                <span for="gwt-uid-4444">Balance After Transfer</span>
                                                                <div class="gwt-Label" id="gwt-uid-4444">0.00</div>
                                                                <!-- <div class="error-panel"></div> -->
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xs-12" aria-hidden="true" style="display: none;">
                                            <hr />
                                            <div class="alert alert-info"><strong> Resulting Exchange Rates </strong> <span class="A54VNK-Re-b"></span> <span class="A54VNK-Re-b"></span></div>
                                        </div>
                                    </div>
                                    <div>
                                        <hr />
                                        <h4>Attachments</h4>
                                        <div class="row">
                                            <div>
                                                <div class="A54VNK-Qb-a" aria-hidden="true" style="display: none;">
                                                    <div class="A54VNK-Qb-c">
                                                        <div class="A54VNK-Qb-d">
                                                            <div class="picto-font A54VNK-Qb-h">c</div>
                                                            <div class="A54VNK-Qb-g bolder">Drop files to start upload</div>
                                                            <div aria-hidden="true" style="display: none;">
                                                                <div class="progress"><div class="progress-bar" role="progressbar"></div></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="A54VNK-yh-d">
                                                    <label for="gwt-uid-4494"></label> <span class="A54VNK-yh-c text-danger" aria-hidden="true" style="display: none;"> <span></span> deleted ( <a class="" role="button">Undo</a> ) </span>
                                                </div>
                                                <div class="A54VNK-yh-a">
                                                    <div class="row A54VNK-yh-b"></div>
                                                    <div class="A54VNK-Rj-b" id="gwt-uid-4494">
                                                        <div class="A54VNK-Rj-e">
                                                            <div class="picto-font A54VNK-Rj-d"></div>
                                                            <div>Drag files to attach</div>
                                                            , or <button type="button" class="btn btn-link A54VNK-Rj-a">Browse files from your device</button>
                                                        </div>
                                                        <div class="text-muted A54VNK-Rj-c">or</div>
                                                        <button type="button" class="btn btn-default">Browse uploaded files</button>
                                                    </div>
                                                </div>
                                                <div class="error-panel"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>

                    <new-footer type="basic"/>
                </div>
            </div>
        </div>
    </form>

    <!-- form section -->
</template>

<script>
    import NewFooter from '../../../layouts/partials/new_footer'

    export default {
        components: {
            NewFooter,
        },
        name: 'Purchaseorder',
        data: function () {
            return {
                loaded: false,
                form: new Form({
                    "id": "",
                    "supplier": "",
                    "address": "",
                    "recipient": "",
                    "ref_number": "",
                    "date": "",
                    "payment_terms": "",
                    "currency": "",
                    "product": "",
                    "document_note": "",
                    "subtotal": "",
                    "discount_rate": "",
                    "discount_amount": "",
                    "vat": "",
                    "total": "",
                    "delivery_date": "",
                    "type": "",
                    "delivery_address": "",
                    "project": "",
                    "delivery_status": "",
                    "billing_status": "",
                    "assigned_to": "",
                    "private_note": "",
                    "attachments": "",
                    "created_at": "",
                    "updated_at": "",
                })
            }
        },
        created: function () {
            this.getPurchaseorder();
        },
        methods: {
            getPurchaseorder: function (Purchaseorder) {

                var that = this;
                this.form.get('/api/purchaseorders/' + this.$route.params.id).then(function (response) {
                    that.form.fill(response.data);
                    that.loaded = true;
                });

            },
            updatePurchaseorder: function () {

                var that = this;
                this.form.put('/api/purchaseorders/' + this.$route.params.id).then(function (response) {
                    that.form.fill(response.data);
                })

            },
            deletePurchaseorder: function () {

                var that = this;
                this.form.delete('/api/purchaseorders/' + this.$route.params.id).then(function (response) {
                    that.form.fill(response.data);
                    that.$router.push('/super-admin/purchaseorders');
                })

            }
        }
    }
</script>
