<template>
    <!-- form section -->

    <form>
        <div class="right-content form1">
            <div id="contentRootPanel" class="fullpage">
                <div class="A54VNK-ce-a">
                    <div class="page-panel panel-default page-right-content">
                        <div class="panel-body page-panel-body">
                            <div data-id="v192168000022_1115908479125_230">
                                <div data-id="v192168000022_1115908766218_265">
                                    <div>
                                        <div class="form-horizontal">
                                            <div class="form-group row" data-id="v192168000022_1115908766218_269">
                                                <div class="col-sm-4 col-xs-4 control-label"><label class="" for="gwt-uid-4828" style="font-weight: normal;">What template do you want to use?</label><span class="text-danger bold">*</span></div>
                                                <div class="col-sm-8 col-xs-8">
                                                    <div class="A54VNK-Ji-a">
                                                        <div class="select-panel A54VNK-Ji-c">
                                                            <select class="form-control" size="1" id="gwt-uid-4828">
                                                                <option value="ACCOUNTING_RECEIPT_LOAN">Incoming Payment from Loan</option>
                                                                <option value="ACCOUNTING_RECEIPT_OPENING_BALANCE_CUSTOMER">Opening Balance: Customer</option>
                                                                <option value="ACCOUNTING_RECEIPT_VENDOR_TAX_REFUND">VAT Refund</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group row" data-id="v192168000022_1115908766218_271">
                                                <div class="col-sm-4 col-xs-4 control-label">
                                                    <label class="" for="gwt-uid-4830" style="font-weight: normal;">Date Deposited</label><span class="text-danger bold" aria-hidden="true" style="display: none;">*</span>
                                                </div>
                                                <div class="col-sm-8 col-xs-8">
                                                    <div class="input-group">
                                                        <input type="text" class="form-control" id="gwt-uid-4830" />
                                                        <div class="input-group-btn">
                                                            <button type="button" class="btn btn-default" tabindex="-1"><span class="picto-font">\</span></button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group row" data-id="v192168000022_1115908766218_275">
                                                <div class="col-sm-4 col-xs-4 control-label"><label class="" for="gwt-uid-4855" style="font-weight: normal;">Account</label><span class="text-danger bold">*</span></div>
                                                <div class="col-sm-8 col-xs-8">
                                                    <div class="dropdown">
                                                        <input type="text" class="form-control A54VNK-Ki-b" data-toggle="dropdown" autocomplete="off" role="button" placeholder="Search results" id="gwt-uid-4855" />
                                                        <ul class="dropdown-menu A54VNK-Ki-a">
                                                            <li class="active">
                                                                <a class="ellipsis-block" role="button" title="27300  ( Bank Loan )"><strong>27300</strong> ( <strong>Bank</strong> <strong>Loan</strong> )</a>
                                                            </li>
                                                            <li class="divider"></li>
                                                            <li class=""><a class="ellipsis-block" role="button">Start the search</a></li>
                                                            <li class=""><a class="ellipsis-block" role="button">Create a new...</a></li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group row" data-id="v192168000022_1115908766218_274">
                                                <div class="col-sm-4 col-xs-4 control-label"><label class="" for="gwt-uid-4857" style="font-weight: normal;">Total incl VAT</label><span class="text-danger bold">*</span></div>
                                                <div class="col-sm-8 col-xs-8"><input type="text" class="form-control" id="gwt-uid-4857" style="text-align: right;" /></div>
                                            </div>
                                            <div class="form-group row" data-id="v192168000022_1115908766234_293">
                                                <div class="col-sm-12"><span class="">Payment Terms</span></div>
                                            </div>
                                            <div class="form-group row" data-id="v192168000022_1115908766234_294">
                                                <div class="col-sm-4 col-xs-4 control-label">
                                                    <label class="" for="gwt-uid-4901" style="font-weight: normal;">Payment Method</label><span class="text-danger bold" aria-hidden="true" style="display: none;">*</span>
                                                </div>
                                                <div class="col-sm-8 col-xs-8">
                                                    <div class="A54VNK-Ji-a">
                                                        <div class="select-panel A54VNK-Ji-c">
                                                            <select class="form-control" size="1" id="gwt-uid-4901">
                                                                <option value="3">Cash</option>
                                                                <option value="1">Cheque</option>
                                                                <option value="11">Credit Note</option>
                                                                <option value="2">Debit/Credit Card</option>
                                                                <option value="4">Direct Debit/ACH</option>
                                                                <option value="10">Gift Certificate</option>
                                                                <option value="7">Other</option>
                                                                <option value="5">Wire Transfer</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group row SimpleTextQuestion" data-id="v192168000022_1115908766234_295">
                                                <div class="col-sm-4 col-xs-4 control-label">
                                                    <label class="" for="gwt-uid-4902" style="font-weight: normal;">Bank Reference</label><span class="text-danger bold" aria-hidden="true" style="display: none;">*</span>
                                                </div>
                                                <div class="col-sm-8 col-xs-8"><input type="text" class="form-control" id="gwt-uid-4902" /></div>
                                            </div>
                                            <div class="form-group row" data-id="v192168000022_1115908766234_297">
                                                <div class="col-sm-4 col-xs-4 control-label">
                                                    <label class="" for="gwt-uid-4905" style="font-weight: normal;">Bank account debited/credited</label>
                                                    <span class="text-danger bold" aria-hidden="true" style="display: none;">*</span>
                                                </div>
                                                <div class="col-sm-8 col-xs-8">
                                                    <div class="A54VNK-Ji-a">
                                                        <div class="select-panel A54VNK-Ji-c">
                                                            <select class="form-control" size="1" id="gwt-uid-4905">
                                                                <option value="37788">asia bank Savings Account</option>
                                                                <option value="37757">city bank Current Account</option>
                                                                <option value="0">To be deposited later</option>
                                                            </select>
                                                        </div>
                                                        <!-- <button type="button" class="btn btn-link A54VNK-Ji-b" style=""><span class="picto-font"></span></button> -->
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group" data-id="v192168000022_1115908766234_298">
                                                <div class="col-sm-12"><span class="">Detail</span></div>
                                            </div>
                                            <div class="form-group row" data-id="v192168001109_1309273285934_2262">
                                                <div class="col-sm-4 col-xs-4 control-label">
                                                    <label class="" for="gwt-uid-4911" style="font-weight: normal;">Project</label>
                                                    <span class="text-danger bold" aria-hidden="true" style="display: none;">*</span>
                                                </div>
                                                <div class="col-sm-8 col-xs-8">
                                                    <div class="dropdown">
                                                        <!-- <a class="A54VNK-Li-a" style=""><span class="picto-font">D</span></a> -->
                                                        <input type="text" class="form-control A54VNK-Li-d" data-toggle="dropdown" autocomplete="off" role="button" id="gwt-uid-4911" placeholder="Project name" />
                                                        <ul class="dropdown-menu A54VNK-Li-c">
                                                            <li class="disabled"><a> No result </a></li>
                                                            <li class="divider"></li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group row SimpleTextQuestion" data-id="v192168000022_1115908766234_304">
                                                <div class="col-sm-4 col-xs-4 control-label">
                                                    <label class="" for="gwt-uid-4915" style="font-weight: normal;">Description or Note</label>
                                                    <span class="text-danger bold" aria-hidden="true" style="display: none;">*</span>
                                                </div>
                                                <div class="col-sm-8 col-xs-8"><input type="text" class="form-control" id="gwt-uid-4915" /></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="btn-toolbar A54VNK-fj-a" aria-hidden="true" style="display: none;"></div>
                                    <hr />
                                </div>
                            </div>
                        </div>

                    </div>

                    <new-footer type="basic"/>
                </div>
            </div>
        </div>
    </form>

    <!-- form section -->
</template>

<script>
    import NewFooter from '../../../layouts/partials/new_footer'

    export default {
        components: {
            NewFooter,
        },
        name: 'Purchaseorder',
        data: function () {
            return {
                loaded: false,
                form: new Form({
                    "id": "",
                    "supplier": "",
                    "address": "",
                    "recipient": "",
                    "ref_number": "",
                    "date": "",
                    "payment_terms": "",
                    "currency": "",
                    "product": "",
                    "document_note": "",
                    "subtotal": "",
                    "discount_rate": "",
                    "discount_amount": "",
                    "vat": "",
                    "total": "",
                    "delivery_date": "",
                    "type": "",
                    "delivery_address": "",
                    "project": "",
                    "delivery_status": "",
                    "billing_status": "",
                    "assigned_to": "",
                    "private_note": "",
                    "attachments": "",
                    "created_at": "",
                    "updated_at": "",
                })
            }
        },
        created: function () {
            this.getPurchaseorder();
        },
        methods: {
            getPurchaseorder: function (Purchaseorder) {

                var that = this;
                this.form.get('/api/purchaseorders/' + this.$route.params.id).then(function (response) {
                    that.form.fill(response.data);
                    that.loaded = true;
                });

            },
            updatePurchaseorder: function () {

                var that = this;
                this.form.put('/api/purchaseorders/' + this.$route.params.id).then(function (response) {
                    that.form.fill(response.data);
                })

            },
            deletePurchaseorder: function () {

                var that = this;
                this.form.delete('/api/purchaseorders/' + this.$route.params.id).then(function (response) {
                    that.form.fill(response.data);
                    that.$router.push('/super-admin/purchaseorders');
                })

            }
        }
    }
</script>
