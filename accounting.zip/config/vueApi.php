<?php
return [
    'model_dir' => base_path('app/Model'),
    'controller_dir' => base_path('app/Http/Admin'),
    'vue_files_dir' => base_path('resources/js/components/purchase/testsohans'),
    'vue_url_prefix' => '/api',
    'routes_dir' => base_path('routes'),
    'routes_file' => 'api.php'
];
?>
