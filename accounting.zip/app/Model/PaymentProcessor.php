<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class PaymentProcessor extends Model
{
    protected $guarded = [];
}
