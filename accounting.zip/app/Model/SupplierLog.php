<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class SupplierLog extends Model
{
    protected $guarded = [];
}
