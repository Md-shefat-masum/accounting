<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RecieptExpense extends Model
{
    //
}
